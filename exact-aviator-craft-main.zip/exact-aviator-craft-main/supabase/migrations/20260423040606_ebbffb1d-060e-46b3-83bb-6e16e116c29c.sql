
-- Sounds table
CREATE TABLE IF NOT EXISTS public.game_sounds (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_key TEXT NOT NULL UNIQUE,
  label TEXT NOT NULL,
  audio_url TEXT,
  volume NUMERIC NOT NULL DEFAULT 0.6 CHECK (volume >= 0 AND volume <= 1),
  loop BOOLEAN NOT NULL DEFAULT false,
  is_enabled BOOLEAN NOT NULL DEFAULT true,
  updated_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.game_sounds ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone authenticated can view enabled sounds" ON public.game_sounds;
CREATE POLICY "Anyone authenticated can view enabled sounds"
  ON public.game_sounds
  FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Public can view enabled sounds" ON public.game_sounds;
CREATE POLICY "Public can view enabled sounds"
  ON public.game_sounds
  FOR SELECT
  TO anon
  USING (is_enabled = true);

DROP POLICY IF EXISTS "Admins manage game sounds" ON public.game_sounds;
CREATE POLICY "Admins manage game sounds"
  ON public.game_sounds
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_game_sounds_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_touch_game_sounds ON public.game_sounds;
CREATE TRIGGER trg_touch_game_sounds
BEFORE UPDATE ON public.game_sounds
FOR EACH ROW EXECUTE FUNCTION public.touch_game_sounds_updated_at();

-- Seed default events
INSERT INTO public.game_sounds (event_key, label, loop, volume) VALUES
  ('background', 'Background Ambient', true, 0.25),
  ('takeoff', 'Flight Takeoff', false, 0.7),
  ('flying', 'Flying Loop', true, 0.5),
  ('tension', 'Tension Build', true, 0.5),
  ('high_multiplier', 'High Multiplier', true, 0.6),
  ('cashout', 'Cashout / Win', false, 0.8),
  ('crash', 'Crash', false, 0.8),
  ('ui_tap', 'UI Interaction', false, 0.5)
ON CONFLICT (event_key) DO NOTHING;

-- Storage bucket for sounds
INSERT INTO storage.buckets (id, name, public)
VALUES ('game-sounds', 'game-sounds', true)
ON CONFLICT (id) DO UPDATE SET public = true;

DROP POLICY IF EXISTS "Public read game-sounds" ON storage.objects;
CREATE POLICY "Public read game-sounds"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'game-sounds');

DROP POLICY IF EXISTS "Admins upload game-sounds" ON storage.objects;
CREATE POLICY "Admins upload game-sounds"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'game-sounds' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins update game-sounds" ON storage.objects;
CREATE POLICY "Admins update game-sounds"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'game-sounds' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins delete game-sounds" ON storage.objects;
CREATE POLICY "Admins delete game-sounds"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'game-sounds' AND public.has_role(auth.uid(), 'admin'));
