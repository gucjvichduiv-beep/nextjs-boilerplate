-- Add image_url column to plane_settings
ALTER TABLE public.plane_settings
  ADD COLUMN IF NOT EXISTS image_url TEXT;

-- Change default balances on profiles to 0
ALTER TABLE public.profiles
  ALTER COLUMN balance_inr SET DEFAULT 0,
  ALTER COLUMN balance_usd SET DEFAULT 0;

-- Reset all existing balances to 0
UPDATE public.profiles SET balance_inr = 0, balance_usd = 0;

-- Create storage bucket for plane images
INSERT INTO storage.buckets (id, name, public)
VALUES ('plane-images', 'plane-images', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for plane-images
DROP POLICY IF EXISTS "Plane images are publicly accessible" ON storage.objects;
CREATE POLICY "Plane images are publicly accessible"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'plane-images');

DROP POLICY IF EXISTS "Admins can upload plane images" ON storage.objects;
CREATE POLICY "Admins can upload plane images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'plane-images' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can update plane images" ON storage.objects;
CREATE POLICY "Admins can update plane images"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'plane-images' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can delete plane images" ON storage.objects;
CREATE POLICY "Admins can delete plane images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'plane-images' AND public.has_role(auth.uid(), 'admin'));

-- Update handle_new_user to give 0 balance
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles (id, username, is_guest, avatar_seed, balance_inr, balance_usd)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'p' || substr(NEW.id::text, 1, 4)),
    COALESCE((NEW.raw_user_meta_data->>'is_guest')::boolean, true),
    substr(md5(NEW.id::text), 1, 8),
    0,
    0
  );
  RETURN NEW;
END;
$function$;