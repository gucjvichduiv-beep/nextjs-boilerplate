
-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('deposit-screenshots', 'deposit-screenshots', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('payment-assets', 'payment-assets', true) ON CONFLICT (id) DO NOTHING;

-- Storage policies for deposit-screenshots: users upload to their own folder, anyone can read (public bucket)
CREATE POLICY "Public read deposit screenshots"
ON storage.objects FOR SELECT
USING (bucket_id = 'deposit-screenshots');

CREATE POLICY "Users upload own deposit screenshot"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'deposit-screenshots' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Storage policies for payment-assets: public read, admin write
CREATE POLICY "Public read payment assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'payment-assets');

CREATE POLICY "Admins upload payment assets"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'payment-assets' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update payment assets"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'payment-assets' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete payment assets"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'payment-assets' AND public.has_role(auth.uid(), 'admin'));

-- Seed default admin payment settings if missing
INSERT INTO public.admin_payment_settings (upi_id, upi_name, deposit_note, withdrawal_note, is_active)
SELECT 'admin@upi', 'Aviator Admin', 'Pay to the UPI above. After paying, enter your UTR number and upload a screenshot.', 'Withdrawals are processed within 24 hours.', true
WHERE NOT EXISTS (SELECT 1 FROM public.admin_payment_settings WHERE is_active = true);

-- RPC to create deposit request
CREATE OR REPLACE FUNCTION public.create_deposit_request(
  _amount NUMERIC,
  _currency TEXT,
  _utr TEXT,
  _screenshot_url TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_request public.deposit_requests%ROWTYPE;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF _amount <= 0 THEN
    RAISE EXCEPTION 'Invalid amount';
  END IF;
  IF length(coalesce(_utr, '')) < 6 THEN
    RAISE EXCEPTION 'Invalid UTR';
  END IF;

  INSERT INTO public.deposit_requests (user_id, amount, currency, utr, screenshot_url)
  VALUES (auth.uid(), _amount, _currency, _utr, _screenshot_url)
  RETURNING * INTO new_request;

  RETURN to_jsonb(new_request);
END;
$$;
