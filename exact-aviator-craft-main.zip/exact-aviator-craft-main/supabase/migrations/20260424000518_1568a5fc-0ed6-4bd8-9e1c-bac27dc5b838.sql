
-- RPC: list all users for admins
CREATE OR REPLACE FUNCTION public.admin_list_users()
RETURNS TABLE (
  user_id uuid,
  email text,
  username text,
  is_guest boolean,
  balance_inr numeric,
  balance_usd numeric,
  currency text,
  created_at timestamptz,
  is_admin boolean
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    p.id AS user_id,
    au.email::text AS email,
    p.username,
    p.is_guest,
    p.balance_inr,
    p.balance_usd,
    p.currency,
    p.created_at,
    EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = p.id AND ur.role = 'admin') AS is_admin
  FROM public.profiles p
  LEFT JOIN auth.users au ON au.id = p.id
  WHERE public.has_role(auth.uid(), 'admin')
  ORDER BY p.created_at DESC
  LIMIT 500;
$$;

-- RPC: adjust user balance manually (admin only)
CREATE OR REPLACE FUNCTION public.admin_adjust_balance(
  _user_id uuid,
  _currency text,
  _delta numeric
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  prof public.profiles%ROWTYPE;
  new_inr numeric;
  new_usd numeric;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT * INTO prof FROM public.profiles WHERE id = _user_id;
  IF prof.id IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  IF _currency NOT IN ('INR', 'USD') THEN
    RAISE EXCEPTION 'Invalid currency';
  END IF;

  new_inr := prof.balance_inr + CASE WHEN _currency = 'INR' THEN _delta ELSE 0 END;
  new_usd := prof.balance_usd + CASE WHEN _currency = 'USD' THEN _delta ELSE 0 END;

  IF new_inr < 0 OR new_usd < 0 THEN
    RAISE EXCEPTION 'Balance cannot be negative';
  END IF;

  UPDATE public.profiles
  SET balance_inr = new_inr,
      balance_usd = new_usd
  WHERE id = _user_id;

  RETURN jsonb_build_object('ok', true, 'balance_inr', new_inr, 'balance_usd', new_usd);
END;
$$;
