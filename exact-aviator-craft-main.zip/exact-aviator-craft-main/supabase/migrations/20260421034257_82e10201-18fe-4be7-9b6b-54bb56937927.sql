CREATE OR REPLACE FUNCTION public.compute_multiplier_db(elapsed_ms BIGINT)
RETURNS NUMERIC
LANGUAGE SQL
IMMUTABLE
SET search_path = public
AS $$
  SELECT GREATEST(1::numeric, 1 + 0.05 * (elapsed_ms::numeric / 1000) + 0.05 * power((elapsed_ms::numeric / 1000), 1.7))
$$;

CREATE OR REPLACE FUNCTION public.settle_auto_cashouts(_round_id BIGINT, _current_mult NUMERIC)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  payout RECORD;
BEGIN
  FOR payout IN
    UPDATE public.bets b
    SET cashout_at = ROUND(b.auto_cashout::numeric, 2),
        win_amount = ROUND((b.amount * b.auto_cashout)::numeric, 2),
        status = 'won'
    WHERE b.round_id = _round_id
      AND b.status = 'pending'
      AND b.auto_cashout IS NOT NULL
      AND b.auto_cashout <= _current_mult
    RETURNING b.user_id, b.currency, b.win_amount
  LOOP
    UPDATE public.profiles
    SET balance_inr = CASE WHEN payout.currency = 'INR' THEN balance_inr + payout.win_amount ELSE balance_inr END,
        balance_usd = CASE WHEN payout.currency = 'USD' THEN balance_usd + payout.win_amount ELSE balance_usd END
    WHERE id = payout.user_id;
  END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION public.mark_round_losses(_round_id BIGINT)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.bets
  SET status = 'lost',
      win_amount = 0
  WHERE round_id = _round_id
    AND status = 'pending';
END;
$$;

CREATE OR REPLACE FUNCTION public.advance_game_round()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  now_ts TIMESTAMPTZ := now();
  latest public.game_rounds%ROWTYPE;
  elapsed_ms BIGINT;
  current_mult NUMERIC;
  recent JSONB;
BEGIN
  SELECT * INTO latest
  FROM public.game_rounds
  ORDER BY id DESC
  LIMIT 1;

  IF latest.id IS NULL THEN
    INSERT INTO public.game_rounds (phase, crash_at, waiting_until)
    VALUES ('waiting',
      CASE
        WHEN random() < 0.03 THEN 1.0
        ELSE GREATEST(1.01, ROUND(LEAST((0.97 / (1 - random())), 1000)::numeric, 2))
      END,
      now_ts + interval '5.5 seconds'
    )
    RETURNING * INTO latest;
  ELSIF latest.phase = 'waiting' THEN
    IF now_ts >= latest.waiting_until THEN
      UPDATE public.game_rounds
      SET phase = 'flying',
          flying_started_at = now_ts
      WHERE id = latest.id
      RETURNING * INTO latest;
    END IF;
  ELSIF latest.phase = 'flying' THEN
    elapsed_ms := GREATEST(0, FLOOR(EXTRACT(EPOCH FROM (now_ts - COALESCE(latest.flying_started_at, now_ts))) * 1000))::BIGINT;
    current_mult := public.compute_multiplier_db(elapsed_ms);

    PERFORM public.settle_auto_cashouts(latest.id, LEAST(current_mult, latest.crash_at));

    IF current_mult >= latest.crash_at AND elapsed_ms >= 1500 THEN
      UPDATE public.game_rounds
      SET phase = 'crashed',
          crashed_at = now_ts
      WHERE id = latest.id
      RETURNING * INTO latest;

      PERFORM public.mark_round_losses(latest.id);
    END IF;
  ELSIF latest.phase = 'crashed' THEN
    IF now_ts >= COALESCE(latest.crashed_at, now_ts) + interval '3 seconds' THEN
      INSERT INTO public.game_rounds (phase, crash_at, waiting_until)
      VALUES ('waiting',
        CASE
          WHEN random() < 0.03 THEN 1.0
          ELSE GREATEST(1.01, ROUND(LEAST((0.97 / (1 - random())), 1000)::numeric, 2))
        END,
        now_ts + interval '5.5 seconds'
      )
      RETURNING * INTO latest;
    END IF;
  END IF;

  SELECT COALESCE(
    jsonb_agg(jsonb_build_object('id', r.id, 'crash_at', r.crash_at) ORDER BY r.id DESC),
    '[]'::jsonb
  )
  INTO recent
  FROM (
    SELECT id, crash_at
    FROM public.game_rounds
    WHERE phase = 'crashed'
    ORDER BY id DESC
    LIMIT 20
  ) r;

  RETURN jsonb_build_object(
    'round', to_jsonb(latest),
    'recent', recent,
    'serverTime', FLOOR(EXTRACT(EPOCH FROM now_ts) * 1000)
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.player_cashout(_bet_id BIGINT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  bet_row public.bets%ROWTYPE;
  round_row public.game_rounds%ROWTYPE;
  elapsed_ms BIGINT;
  mult NUMERIC;
  win NUMERIC;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  SELECT * INTO bet_row
  FROM public.bets
  WHERE id = _bet_id
    AND user_id = auth.uid();

  IF bet_row.id IS NULL THEN
    RAISE EXCEPTION 'Bet not found';
  END IF;

  IF bet_row.status <> 'pending' THEN
    RAISE EXCEPTION 'Bet already settled';
  END IF;

  SELECT * INTO round_row
  FROM public.game_rounds
  WHERE id = bet_row.round_id;

  IF round_row.id IS NULL OR round_row.phase <> 'flying' THEN
    RAISE EXCEPTION 'Round not flying';
  END IF;

  elapsed_ms := GREATEST(0, FLOOR(EXTRACT(EPOCH FROM (now() - COALESCE(round_row.flying_started_at, now()))) * 1000))::BIGINT;
  mult := ROUND(LEAST(public.compute_multiplier_db(elapsed_ms), round_row.crash_at)::numeric, 2);
  win := ROUND((bet_row.amount * mult)::numeric, 2);

  UPDATE public.bets
  SET cashout_at = mult,
      win_amount = win,
      status = 'won'
  WHERE id = bet_row.id
    AND status = 'pending';

  UPDATE public.profiles
  SET balance_inr = CASE WHEN bet_row.currency = 'INR' THEN balance_inr + win ELSE balance_inr END,
      balance_usd = CASE WHEN bet_row.currency = 'USD' THEN balance_usd + win ELSE balance_usd END
  WHERE id = bet_row.user_id;

  RETURN jsonb_build_object('ok', TRUE, 'multiplier', mult, 'win', win);
END;
$$;

CREATE OR REPLACE FUNCTION public.create_withdrawal_request(_amount NUMERIC, _currency TEXT, _upi_id TEXT, _account_name TEXT DEFAULT NULL)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  profile_row public.profiles%ROWTYPE;
  new_request public.withdrawal_requests%ROWTYPE;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  SELECT * INTO profile_row
  FROM public.profiles
  WHERE id = auth.uid();

  IF profile_row.id IS NULL THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  IF _amount <= 0 THEN
    RAISE EXCEPTION 'Invalid amount';
  END IF;

  IF _currency = 'INR' AND profile_row.balance_inr < _amount THEN
    RAISE EXCEPTION 'Insufficient INR balance';
  END IF;

  IF _currency = 'USD' AND profile_row.balance_usd < _amount THEN
    RAISE EXCEPTION 'Insufficient USD balance';
  END IF;

  UPDATE public.profiles
  SET balance_inr = CASE WHEN _currency = 'INR' THEN balance_inr - _amount ELSE balance_inr END,
      balance_usd = CASE WHEN _currency = 'USD' THEN balance_usd - _amount ELSE balance_usd END
  WHERE id = auth.uid();

  INSERT INTO public.withdrawal_requests (user_id, amount, currency, upi_id, account_name)
  VALUES (auth.uid(), _amount, _currency, _upi_id, _account_name)
  RETURNING * INTO new_request;

  RETURN to_jsonb(new_request);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_review_deposit(_request_id UUID, _approve BOOLEAN, _admin_note TEXT DEFAULT NULL)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  req public.deposit_requests%ROWTYPE;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT * INTO req
  FROM public.deposit_requests
  WHERE id = _request_id;

  IF req.id IS NULL OR req.status <> 'pending' THEN
    RETURN FALSE;
  END IF;

  IF _approve THEN
    UPDATE public.profiles
    SET balance_inr = CASE WHEN req.currency = 'INR' THEN balance_inr + req.amount ELSE balance_inr END,
        balance_usd = CASE WHEN req.currency = 'USD' THEN balance_usd + req.amount ELSE balance_usd END
    WHERE id = req.user_id;
  END IF;

  UPDATE public.deposit_requests
  SET status = CASE WHEN _approve THEN 'approved' ELSE 'rejected' END,
      admin_note = _admin_note,
      reviewed_by = auth.uid(),
      reviewed_at = now(),
      updated_at = now()
  WHERE id = _request_id;

  RETURN TRUE;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_review_withdrawal(_request_id UUID, _approve BOOLEAN, _admin_note TEXT DEFAULT NULL)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  req public.withdrawal_requests%ROWTYPE;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT * INTO req
  FROM public.withdrawal_requests
  WHERE id = _request_id;

  IF req.id IS NULL OR req.status <> 'pending' THEN
    RETURN FALSE;
  END IF;

  IF NOT _approve THEN
    UPDATE public.profiles
    SET balance_inr = CASE WHEN req.currency = 'INR' THEN balance_inr + req.amount ELSE balance_inr END,
        balance_usd = CASE WHEN req.currency = 'USD' THEN balance_usd + req.amount ELSE balance_usd END
    WHERE id = req.user_id;
  END IF;

  UPDATE public.withdrawal_requests
  SET status = CASE WHEN _approve THEN 'approved' ELSE 'rejected' END,
      admin_note = _admin_note,
      reviewed_by = auth.uid(),
      reviewed_at = now(),
      updated_at = now()
  WHERE id = _request_id;

  RETURN TRUE;
END;
$$;

DROP POLICY IF EXISTS "Authenticated users can create shared rounds" ON public.game_rounds;
DROP POLICY IF EXISTS "Authenticated users can advance shared rounds" ON public.game_rounds;