
CREATE OR REPLACE FUNCTION public.admin_review_deposit(_request_id uuid, _approve boolean, _admin_note text DEFAULT NULL::text)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  req public.deposit_requests%ROWTYPE;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT * INTO req
  FROM public.deposit_requests
  WHERE id = _request_id;

  IF req.id IS NULL OR req.status <> 'pending'::public.wallet_request_status THEN
    RETURN FALSE;
  END IF;

  IF _approve THEN
    UPDATE public.profiles
    SET balance_inr = CASE WHEN req.currency = 'INR' THEN balance_inr + req.amount ELSE balance_inr END,
        balance_usd = CASE WHEN req.currency = 'USD' THEN balance_usd + req.amount ELSE balance_usd END
    WHERE id = req.user_id;
  END IF;

  UPDATE public.deposit_requests
  SET status = (CASE WHEN _approve THEN 'approved' ELSE 'rejected' END)::public.wallet_request_status,
      admin_note = _admin_note,
      reviewed_by = auth.uid(),
      reviewed_at = now(),
      updated_at = now()
  WHERE id = _request_id;

  RETURN TRUE;
END;
$function$;

CREATE OR REPLACE FUNCTION public.admin_review_withdrawal(_request_id uuid, _approve boolean, _admin_note text DEFAULT NULL::text)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  req public.withdrawal_requests%ROWTYPE;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT * INTO req
  FROM public.withdrawal_requests
  WHERE id = _request_id;

  IF req.id IS NULL OR req.status <> 'pending'::public.wallet_request_status THEN
    RETURN FALSE;
  END IF;

  IF NOT _approve THEN
    UPDATE public.profiles
    SET balance_inr = CASE WHEN req.currency = 'INR' THEN balance_inr + req.amount ELSE balance_inr END,
        balance_usd = CASE WHEN req.currency = 'USD' THEN balance_usd + req.amount ELSE balance_usd END
    WHERE id = req.user_id;
  END IF;

  UPDATE public.withdrawal_requests
  SET status = (CASE WHEN _approve THEN 'approved' ELSE 'rejected' END)::public.wallet_request_status,
      admin_note = _admin_note,
      reviewed_by = auth.uid(),
      reviewed_at = now(),
      updated_at = now()
  WHERE id = _request_id;

  RETURN TRUE;
END;
$function$;
