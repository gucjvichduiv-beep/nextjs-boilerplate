
-- Plane appearance settings
CREATE TABLE IF NOT EXISTS public.plane_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  is_active BOOLEAN NOT NULL DEFAULT true,
  body_color TEXT NOT NULL DEFAULT '#e50539',
  accent_color TEXT NOT NULL DEFAULT '#ffffff',
  trail_color TEXT NOT NULL DEFAULT '#e50539',
  style TEXT NOT NULL DEFAULT 'classic',
  scale NUMERIC NOT NULL DEFAULT 1.0 CHECK (scale > 0 AND scale <= 3),
  updated_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.plane_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view active plane settings" ON public.plane_settings;
CREATE POLICY "Anyone can view active plane settings"
  ON public.plane_settings
  FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

DROP POLICY IF EXISTS "Admins manage plane settings" ON public.plane_settings;
CREATE POLICY "Admins manage plane settings"
  ON public.plane_settings
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.touch_plane_settings_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_touch_plane_settings ON public.plane_settings;
CREATE TRIGGER trg_touch_plane_settings
BEFORE UPDATE ON public.plane_settings
FOR EACH ROW EXECUTE FUNCTION public.touch_plane_settings_updated_at();

INSERT INTO public.plane_settings (is_active, body_color, accent_color, trail_color, style, scale)
SELECT true, '#e50539', '#ffffff', '#e50539', 'classic', 1.0
WHERE NOT EXISTS (SELECT 1 FROM public.plane_settings WHERE is_active = true);

-- Promote existing user to admin (admin-only)
CREATE OR REPLACE FUNCTION public.promote_user_to_admin(_email TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_user_id UUID;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT id INTO target_user_id
  FROM auth.users
  WHERE lower(email) = lower(_email)
  LIMIT 1;

  IF target_user_id IS NULL THEN
    RETURN FALSE;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (target_user_id, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN TRUE;
END;
$$;

-- Demote (revoke admin) — admin-only, cannot demote self
CREATE OR REPLACE FUNCTION public.revoke_admin(_email TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_user_id UUID;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT id INTO target_user_id
  FROM auth.users
  WHERE lower(email) = lower(_email)
  LIMIT 1;

  IF target_user_id IS NULL THEN
    RETURN FALSE;
  END IF;

  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot revoke your own admin role';
  END IF;

  DELETE FROM public.user_roles
  WHERE user_id = target_user_id AND role = 'admin';

  RETURN TRUE;
END;
$$;
