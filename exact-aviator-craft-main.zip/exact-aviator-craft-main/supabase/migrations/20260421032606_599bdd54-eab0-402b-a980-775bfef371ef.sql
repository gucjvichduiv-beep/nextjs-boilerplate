CREATE POLICY "Anyone can create shared rounds"
ON public.game_rounds
FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "Anyone can advance shared rounds"
ON public.game_rounds
FOR UPDATE
TO public
USING (true)
WITH CHECK (true);

CREATE POLICY "Users can create their own bets"
ON public.bets
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bets"
ON public.bets
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);