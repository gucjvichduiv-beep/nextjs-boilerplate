-- Create default admin user: admin@aviator.com / Admin@12345
DO $$
DECLARE
  admin_uid uuid;
  encrypted_pw text;
BEGIN
  -- Check if admin already exists
  SELECT id INTO admin_uid FROM auth.users WHERE lower(email) = 'admin@aviator.com' LIMIT 1;

  IF admin_uid IS NULL THEN
    admin_uid := gen_random_uuid();
    encrypted_pw := crypt('Admin@12345', gen_salt('bf'));

    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token,
      email_change_token_new,
      email_change
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      admin_uid,
      'authenticated',
      'authenticated',
      'admin@aviator.com',
      encrypted_pw,
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"username":"admin","is_guest":false}'::jsonb,
      now(),
      now(),
      '',
      '',
      '',
      ''
    );

    INSERT INTO auth.identities (
      id,
      user_id,
      provider_id,
      identity_data,
      provider,
      last_sign_in_at,
      created_at,
      updated_at
    ) VALUES (
      gen_random_uuid(),
      admin_uid,
      admin_uid::text,
      jsonb_build_object('sub', admin_uid::text, 'email', 'admin@aviator.com', 'email_verified', true),
      'email',
      now(),
      now(),
      now()
    );
  END IF;

  -- Ensure profile exists
  INSERT INTO public.profiles (id, username, is_guest, avatar_seed)
  VALUES (admin_uid, 'admin', false, substr(md5(admin_uid::text), 1, 8))
  ON CONFLICT (id) DO UPDATE SET is_guest = false, username = 'admin';

  -- Grant admin role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (admin_uid, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;
END $$;