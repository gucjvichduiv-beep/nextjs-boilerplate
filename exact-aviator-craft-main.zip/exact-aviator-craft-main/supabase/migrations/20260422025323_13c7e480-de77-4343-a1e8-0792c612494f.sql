
-- Game control settings (single row)
CREATE TABLE IF NOT EXISTS public.game_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode text NOT NULL DEFAULT 'random',          -- 'random' | 'fixed'
  fixed_crash numeric,                           -- when set, next round uses this exact value then clears
  min_crash numeric NOT NULL DEFAULT 1.10,
  max_crash numeric NOT NULL DEFAULT 50.00,
  instant_crash_chance numeric NOT NULL DEFAULT 0.03,  -- probability of instant 1.00x crash in random mode
  is_active boolean NOT NULL DEFAULT true,
  updated_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.game_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view game settings"
ON public.game_settings FOR SELECT TO authenticated
USING (is_active = true);

CREATE POLICY "Admins manage game settings"
ON public.game_settings FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.game_settings (mode, min_crash, max_crash, instant_crash_chance)
SELECT 'random', 1.10, 50.00, 0.03
WHERE NOT EXISTS (SELECT 1 FROM public.game_settings WHERE is_active = true);

-- Helper: pick the next crash value based on settings
CREATE OR REPLACE FUNCTION public.pick_next_crash()
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  s public.game_settings%ROWTYPE;
  result numeric;
BEGIN
  SELECT * INTO s FROM public.game_settings WHERE is_active = true LIMIT 1;
  IF s.id IS NULL THEN
    -- Fallback to legacy behavior
    IF random() < 0.03 THEN
      RETURN 1.00;
    ELSE
      RETURN GREATEST(1.01, ROUND(LEAST((0.97 / (1 - random())), 1000)::numeric, 2));
    END IF;
  END IF;

  -- Fixed override consumed once
  IF s.mode = 'fixed' AND s.fixed_crash IS NOT NULL THEN
    result := GREATEST(1.00, ROUND(s.fixed_crash::numeric, 2));
    UPDATE public.game_settings
       SET fixed_crash = NULL,
           mode = 'random',
           updated_at = now()
     WHERE id = s.id;
    RETURN result;
  END IF;

  -- Random within configured range, with chance of instant crash
  IF random() < COALESCE(s.instant_crash_chance, 0.03) THEN
    RETURN 1.00;
  END IF;

  RETURN ROUND(
    (s.min_crash + (random() * (GREATEST(s.max_crash, s.min_crash) - s.min_crash)))::numeric,
    2
  );
END;
$$;

-- Replace advance_game_round to use pick_next_crash
CREATE OR REPLACE FUNCTION public.advance_game_round()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  now_ts TIMESTAMPTZ := now();
  latest public.game_rounds%ROWTYPE;
  elapsed_ms BIGINT;
  current_mult NUMERIC;
  recent JSONB;
BEGIN
  SELECT * INTO latest
  FROM public.game_rounds
  ORDER BY id DESC
  LIMIT 1;

  IF latest.id IS NULL THEN
    INSERT INTO public.game_rounds (phase, crash_at, waiting_until)
    VALUES ('waiting', public.pick_next_crash(), now_ts + interval '5.5 seconds')
    RETURNING * INTO latest;
  ELSIF latest.phase = 'waiting' THEN
    IF now_ts >= latest.waiting_until THEN
      UPDATE public.game_rounds
      SET phase = 'flying',
          flying_started_at = now_ts
      WHERE id = latest.id
      RETURNING * INTO latest;
    END IF;
  ELSIF latest.phase = 'flying' THEN
    elapsed_ms := GREATEST(0, FLOOR(EXTRACT(EPOCH FROM (now_ts - COALESCE(latest.flying_started_at, now_ts))) * 1000))::BIGINT;
    current_mult := public.compute_multiplier_db(elapsed_ms);

    PERFORM public.settle_auto_cashouts(latest.id, LEAST(current_mult, latest.crash_at));

    IF current_mult >= latest.crash_at AND elapsed_ms >= 1500 THEN
      UPDATE public.game_rounds
      SET phase = 'crashed',
          crashed_at = now_ts
      WHERE id = latest.id
      RETURNING * INTO latest;

      PERFORM public.mark_round_losses(latest.id);
    END IF;
  ELSIF latest.phase = 'crashed' THEN
    IF now_ts >= COALESCE(latest.crashed_at, now_ts) + interval '3 seconds' THEN
      INSERT INTO public.game_rounds (phase, crash_at, waiting_until)
      VALUES ('waiting', public.pick_next_crash(), now_ts + interval '5.5 seconds')
      RETURNING * INTO latest;
    END IF;
  END IF;

  SELECT COALESCE(
    jsonb_agg(jsonb_build_object('id', r.id, 'crash_at', r.crash_at) ORDER BY r.id DESC),
    '[]'::jsonb
  )
  INTO recent
  FROM (
    SELECT id, crash_at
    FROM public.game_rounds
    WHERE phase = 'crashed'
    ORDER BY id DESC
    LIMIT 20
  ) r;

  RETURN jsonb_build_object(
    'round', to_jsonb(latest),
    'recent', recent,
    'serverTime', FLOOR(EXTRACT(EPOCH FROM now_ts) * 1000)
  );
END;
$$;
