
-- Profiles table for user info, balance, currency
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  is_guest boolean NOT NULL DEFAULT true,
  balance_inr numeric(14,2) NOT NULL DEFAULT 6900,
  balance_usd numeric(14,2) NOT NULL DEFAULT 1000,
  currency text NOT NULL DEFAULT 'INR' CHECK (currency IN ('INR','USD')),
  avatar_seed text NOT NULL DEFAULT '1',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profiles are viewable by everyone"
  ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Users update own profile"
  ON public.profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users insert own profile"
  ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Auto-create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, username, is_guest, avatar_seed)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'p' || substr(NEW.id::text, 1, 4)),
    COALESCE((NEW.raw_user_meta_data->>'is_guest')::boolean, true),
    substr(md5(NEW.id::text), 1, 8)
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Game rounds: server drives all rounds. Phase: waiting -> flying -> crashed
CREATE TABLE public.game_rounds (
  id bigserial PRIMARY KEY,
  phase text NOT NULL CHECK (phase IN ('waiting','flying','crashed')),
  crash_at numeric(8,2) NOT NULL,
  flying_started_at timestamptz,
  crashed_at timestamptz,
  waiting_until timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_rounds_created ON public.game_rounds (created_at DESC);

ALTER TABLE public.game_rounds ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Rounds visible to everyone"
  ON public.game_rounds FOR SELECT USING (true);

-- Bets table
CREATE TABLE public.bets (
  id bigserial PRIMARY KEY,
  round_id bigint NOT NULL REFERENCES public.game_rounds(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  avatar_seed text NOT NULL DEFAULT '1',
  panel smallint NOT NULL CHECK (panel IN (1,2)),
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  currency text NOT NULL CHECK (currency IN ('INR','USD')),
  cashout_at numeric(8,2),
  win_amount numeric(14,2),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','won','lost')),
  auto_cashout numeric(8,2),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(round_id, user_id, panel)
);

CREATE INDEX idx_bets_round ON public.bets (round_id);
CREATE INDEX idx_bets_user ON public.bets (user_id);

ALTER TABLE public.bets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Bets visible to everyone"
  ON public.bets FOR SELECT USING (true);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.game_rounds;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bets;
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
