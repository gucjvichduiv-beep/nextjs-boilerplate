
-- Promo codes table
CREATE TABLE public.promo_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  amount numeric NOT NULL CHECK (amount > 0),
  currency text NOT NULL DEFAULT 'INR' CHECK (currency IN ('INR','USD')),
  max_total_uses integer,            -- NULL = unlimited
  max_per_user integer NOT NULL DEFAULT 1 CHECK (max_per_user > 0),
  expires_at timestamptz,            -- NULL = never expires
  is_active boolean NOT NULL DEFAULT true,
  note text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_promo_codes_code ON public.promo_codes (lower(code));

ALTER TABLE public.promo_codes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view active promo codes"
  ON public.promo_codes
  FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Admins manage promo codes"
  ON public.promo_codes
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Redemptions table
CREATE TABLE public.promo_code_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  promo_code_id uuid NOT NULL REFERENCES public.promo_codes(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  amount numeric NOT NULL,
  currency text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_promo_redemptions_user ON public.promo_code_redemptions(user_id);
CREATE INDEX idx_promo_redemptions_code ON public.promo_code_redemptions(promo_code_id);

ALTER TABLE public.promo_code_redemptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own redemptions"
  ON public.promo_code_redemptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- Updated-at trigger for promo_codes
CREATE OR REPLACE FUNCTION public.touch_promo_codes_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_touch_promo_codes
BEFORE UPDATE ON public.promo_codes
FOR EACH ROW
EXECUTE FUNCTION public.touch_promo_codes_updated_at();

-- Redeem function
CREATE OR REPLACE FUNCTION public.redeem_promo_code(_code text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  promo public.promo_codes%ROWTYPE;
  total_used integer;
  user_used integer;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF _code IS NULL OR length(trim(_code)) = 0 THEN
    RAISE EXCEPTION 'Enter a code';
  END IF;

  SELECT * INTO promo
  FROM public.promo_codes
  WHERE lower(code) = lower(trim(_code))
  FOR UPDATE;

  IF promo.id IS NULL THEN
    RAISE EXCEPTION 'Invalid code';
  END IF;

  IF NOT promo.is_active THEN
    RAISE EXCEPTION 'Code is inactive';
  END IF;

  IF promo.expires_at IS NOT NULL AND promo.expires_at < now() THEN
    RAISE EXCEPTION 'Code has expired';
  END IF;

  IF promo.max_total_uses IS NOT NULL THEN
    SELECT count(*) INTO total_used
    FROM public.promo_code_redemptions
    WHERE promo_code_id = promo.id;
    IF total_used >= promo.max_total_uses THEN
      RAISE EXCEPTION 'Code limit reached';
    END IF;
  END IF;

  SELECT count(*) INTO user_used
  FROM public.promo_code_redemptions
  WHERE promo_code_id = promo.id AND user_id = auth.uid();
  IF user_used >= promo.max_per_user THEN
    RAISE EXCEPTION 'You have already used this code';
  END IF;

  UPDATE public.profiles
  SET balance_inr = CASE WHEN promo.currency = 'INR' THEN balance_inr + promo.amount ELSE balance_inr END,
      balance_usd = CASE WHEN promo.currency = 'USD' THEN balance_usd + promo.amount ELSE balance_usd END
  WHERE id = auth.uid();

  INSERT INTO public.promo_code_redemptions (promo_code_id, user_id, amount, currency)
  VALUES (promo.id, auth.uid(), promo.amount, promo.currency);

  RETURN jsonb_build_object('ok', true, 'amount', promo.amount, 'currency', promo.currency);
END;
$$;
