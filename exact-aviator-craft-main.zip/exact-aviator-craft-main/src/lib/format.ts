export function formatMoney(n: number, currency: "INR" | "USD") {
  const v = Number(n || 0).toFixed(2);
  return v;
}

export function currencySymbol(c: "INR" | "USD") {
  return c;
}

export function formatMultiplier(n: number) {
  return n.toFixed(2) + "x";
}

export function multiplierColor(m: number) {
  if (m < 2) return "text-[#1a90ff]";
  if (m < 10) return "text-[#a855f7]";
  return "text-[#ec4899]";
}