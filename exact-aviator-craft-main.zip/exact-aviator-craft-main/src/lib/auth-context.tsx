import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";

type Profile = {
  id: string;
  username: string;
  is_guest: boolean;
  balance_inr: number;
  balance_usd: number;
  currency: "INR" | "USD";
  avatar_seed: string;
};

type AuthCtx = {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  isAdmin: boolean;
  signInGuest: () => Promise<void>;
  signUpEmail: (email: string, password: string, username: string) => Promise<{ error: string | null }>;
  signInEmail: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  setCurrency: (c: "INR" | "USD") => Promise<void>;
  refreshProfile: () => Promise<void>;
  refreshRole: () => Promise<void>;
};

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  const loadProfile = async (uid: string) => {
    const { data } = await supabase.from("profiles").select("*").eq("id", uid).maybeSingle();
    setProfile((data as Profile) ?? null);
  };

  const loadRole = async (uid: string) => {
    const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid).eq("role", "admin");
    setIsAdmin(Boolean(data && data.length > 0));
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        setTimeout(() => {
          void loadProfile(s.user.id);
          void loadRole(s.user.id);
        }, 0);
      } else {
        setProfile(null);
        setIsAdmin(false);
      }
    });

    supabase.auth.getSession().then(async ({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        await Promise.all([loadProfile(s.user.id), loadRole(s.user.id)]);
      }
      setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    const profileChannel = supabase
      .channel("profile-" + user.id)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "profiles", filter: `id=eq.${user.id}` },
        (payload) => setProfile(payload.new as Profile),
      )
      .subscribe();

    const roleChannel = supabase
      .channel("role-" + user.id)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "user_roles", filter: `user_id=eq.${user.id}` },
        async () => {
          await loadRole(user.id);
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(profileChannel);
      supabase.removeChannel(roleChannel);
    };
  }, [user]);

  const signInGuest = async () => {
    await supabase.auth.signInAnonymously();
  };

  const signUpEmail = async (email: string, password: string, username: string) => {
    const redirectUrl = `${window.location.origin}/`;
    if (user && session) {
      const { error } = await supabase.auth.updateUser({
        email,
        password,
        data: { username, is_guest: false },
      });
      if (error) return { error: error.message };
      await supabase.from("profiles").update({ username, is_guest: false }).eq("id", user.id);
      await Promise.all([loadProfile(user.id), loadRole(user.id)]);
      return { error: null };
    }
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: redirectUrl, data: { username, is_guest: false } },
    });
    return { error: error?.message ?? null };
  };

  const signInEmail = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const setCurrency = async (c: "INR" | "USD") => {
    if (!user) return;
    await supabase.from("profiles").update({ currency: c }).eq("id", user.id);
    if (profile) setProfile({ ...profile, currency: c });
  };

  const refreshProfile = async () => {
    if (user) await loadProfile(user.id);
  };

  const refreshRole = async () => {
    if (user) await loadRole(user.id);
  };

  return (
    <Ctx.Provider
      value={{
        user,
        session,
        profile,
        loading,
        isAdmin,
        signInGuest,
        signUpEmail,
        signInEmail,
        signOut,
        setCurrency,
        refreshProfile,
        refreshRole,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used inside AuthProvider");
  return c;
}
