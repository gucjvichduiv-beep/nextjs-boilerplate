// Lightweight sound engine using Web Audio API (no external assets required).
// Plays admin-uploaded HTMLAudio clips when configured; falls back to synthesized
// Web Audio for any event without a custom URL.

import { supabase } from "@/integrations/supabase/client";

export type SoundEvent =
  | "background"
  | "takeoff"
  | "flying"
  | "tension"
  | "high_multiplier"
  | "cashout"
  | "crash"
  | "ui_tap";

type SoundConfig = {
  audio_url: string | null;
  volume: number;
  loop: boolean;
  is_enabled: boolean;
};

const configs: Partial<Record<SoundEvent, SoundConfig>> = {};
const loops: Partial<Record<SoundEvent, HTMLAudioElement>> = {};

let ctx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let enabled = true;
let unlocked = false;
let configsLoaded = false;

// Ambient loop nodes
let ambient: { osc1: OscillatorNode; osc2: OscillatorNode; gain: GainNode; lfo: OscillatorNode; lfoGain: GainNode } | null = null;

// Flying loop nodes
let flying: { noise: AudioBufferSourceNode; filter: BiquadFilterNode; gain: GainNode; hum: OscillatorNode; humGain: GainNode } | null = null;

// Tension loop nodes
let tension: { interval: number } | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
      masterGain = ctx.createGain();
      masterGain.gain.value = 0.6;
      masterGain.connect(ctx.destination);
    } catch {
      return null;
    }
  }
  return ctx;
}

export async function loadSoundConfigs() {
  if (configsLoaded) return;
  configsLoaded = true;
  try {
    const { data } = await supabase.from("game_sounds").select("event_key, audio_url, volume, loop, is_enabled");
    (data ?? []).forEach((row) => {
      configs[row.event_key as SoundEvent] = {
        audio_url: row.audio_url,
        volume: Number(row.volume ?? 0.6),
        loop: Boolean(row.loop),
        is_enabled: Boolean(row.is_enabled),
      };
    });
  } catch {
    /* noop */
  }

  // Live updates from admin
  supabase
    .channel("game-sounds-config")
    .on("postgres_changes", { event: "*", schema: "public", table: "game_sounds" }, (payload) => {
      const row = (payload.new ?? payload.old) as { event_key: SoundEvent } | null;
      if (!row) return;
      const next = payload.new as { audio_url: string | null; volume: number; loop: boolean; is_enabled: boolean; event_key: SoundEvent } | undefined;
      if (next && payload.eventType !== "DELETE") {
        configs[next.event_key] = {
          audio_url: next.audio_url,
          volume: Number(next.volume ?? 0.6),
          loop: Boolean(next.loop),
          is_enabled: Boolean(next.is_enabled),
        };
        // restart background if it's playing
        if (next.event_key === "background" && loops.background) {
          stopCustomLoop("background");
          if (enabled) playCustom("background");
        }
      } else {
        delete configs[row.event_key];
      }
    })
    .subscribe();
}

function getCustomUrl(event: SoundEvent): string | null {
  const cfg = configs[event];
  if (!cfg || !cfg.is_enabled || !cfg.audio_url) return null;
  return cfg.audio_url;
}

function playCustom(event: SoundEvent): boolean {
  const url = getCustomUrl(event);
  if (!url) return false;
  const cfg = configs[event]!;
  try {
    if (cfg.loop) {
      if (loops[event]) return true;
      const a = new Audio(url);
      a.loop = true;
      a.volume = cfg.volume;
      void a.play().catch(() => {});
      loops[event] = a;
    } else {
      const a = new Audio(url);
      a.volume = cfg.volume;
      void a.play().catch(() => {});
    }
    return true;
  } catch {
    return false;
  }
}

function stopCustomLoop(event: SoundEvent) {
  const a = loops[event];
  if (!a) return;
  try {
    a.pause();
    a.src = "";
  } catch {
    /* noop */
  }
  delete loops[event];
}

function makeNoiseBuffer(c: AudioContext, seconds = 2): AudioBuffer {
  const buf = c.createBuffer(1, c.sampleRate * seconds, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  return buf;
}

export function unlockAudio() {
  const c = getCtx();
  if (!c) return;
  if (c.state === "suspended") void c.resume();
  unlocked = true;
  void loadSoundConfigs().then(() => {
    if (!enabled) return;
    if (!playCustom("background")) startAmbient();
  });
}

export function setSoundEnabled(on: boolean) {
  enabled = on;
  if (!on) {
    stopAmbient();
    stopFlying();
    stopTension();
    (Object.keys(loops) as SoundEvent[]).forEach(stopCustomLoop);
    if (masterGain) masterGain.gain.value = 0;
  } else {
    if (masterGain) masterGain.gain.value = 0.6;
    if (unlocked) {
      if (!playCustom("background")) startAmbient();
    }
  }
}

export function isSoundEnabled() {
  return enabled;
}

// ---------- Ambient ----------
function startAmbient() {
  const c = getCtx();
  if (!c || !masterGain || ambient) return;
  const gain = c.createGain();
  gain.gain.value = 0;
  gain.connect(masterGain);

  const osc1 = c.createOscillator();
  osc1.type = "sine";
  osc1.frequency.value = 110;
  const osc2 = c.createOscillator();
  osc2.type = "sine";
  osc2.frequency.value = 165;

  const lfo = c.createOscillator();
  lfo.frequency.value = 0.1;
  const lfoGain = c.createGain();
  lfoGain.gain.value = 8;
  lfo.connect(lfoGain);
  lfoGain.connect(osc1.frequency);

  osc1.connect(gain);
  osc2.connect(gain);
  osc1.start();
  osc2.start();
  lfo.start();

  gain.gain.linearRampToValueAtTime(0.05, c.currentTime + 1.5);
  ambient = { osc1, osc2, gain, lfo, lfoGain };
}

function stopAmbient() {
  if (!ambient || !ctx) return;
  const a = ambient;
  ambient = null;
  a.gain.gain.cancelScheduledValues(ctx.currentTime);
  a.gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
  setTimeout(() => {
    try {
      a.osc1.stop();
      a.osc2.stop();
      a.lfo.stop();
    } catch {
      /* noop */
    }
  }, 600);
}

// ---------- Takeoff ----------
export function playTakeoff() {
  if (playCustom("takeoff")) return;
  const c = getCtx();
  if (!c || !masterGain || !enabled) return;
  const t = c.currentTime;
  const osc = c.createOscillator();
  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(60, t);
  osc.frequency.exponentialRampToValueAtTime(280, t + 1.2);
  const gain = c.createGain();
  gain.gain.setValueAtTime(0, t);
  gain.gain.linearRampToValueAtTime(0.18, t + 0.2);
  gain.gain.linearRampToValueAtTime(0, t + 1.4);
  const filter = c.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 1200;
  osc.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  osc.start(t);
  osc.stop(t + 1.5);
}

// ---------- Flying loop ----------
export function startFlying() {
  if (playCustom("flying")) return;
  const c = getCtx();
  if (!c || !masterGain || !enabled || flying) return;
  const noise = c.createBufferSource();
  noise.buffer = makeNoiseBuffer(c, 2);
  noise.loop = true;
  const filter = c.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.value = 600;
  filter.Q.value = 0.7;
  const gain = c.createGain();
  gain.gain.value = 0;
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  noise.start();

  const hum = c.createOscillator();
  hum.type = "triangle";
  hum.frequency.value = 140;
  const humGain = c.createGain();
  humGain.gain.value = 0;
  hum.connect(humGain);
  humGain.connect(masterGain);
  hum.start();

  gain.gain.linearRampToValueAtTime(0.08, c.currentTime + 0.4);
  humGain.gain.linearRampToValueAtTime(0.04, c.currentTime + 0.4);

  flying = { noise, filter, gain, hum, humGain };
}

export function updateFlying(multiplier: number) {
  if (!flying || !ctx) return;
  const m = Math.min(20, Math.max(1, multiplier));
  const targetFreq = 400 + m * 180;
  const targetHum = 120 + m * 30;
  const targetGain = 0.06 + Math.min(0.12, (m - 1) * 0.02);
  const t = ctx.currentTime;
  flying.filter.frequency.setTargetAtTime(targetFreq, t, 0.15);
  flying.hum.frequency.setTargetAtTime(targetHum, t, 0.15);
  flying.gain.gain.setTargetAtTime(targetGain, t, 0.2);
}

export function stopFlying() {
  stopCustomLoop("flying");
  if (!flying || !ctx) return;
  const f = flying;
  flying = null;
  const t = ctx.currentTime;
  f.gain.gain.cancelScheduledValues(t);
  f.humGain.gain.cancelScheduledValues(t);
  f.gain.gain.linearRampToValueAtTime(0, t + 0.2);
  f.humGain.gain.linearRampToValueAtTime(0, t + 0.2);
  setTimeout(() => {
    try {
      f.noise.stop();
      f.hum.stop();
    } catch {
      /* noop */
    }
  }, 250);
}

// ---------- Tension (heartbeat ticks accelerating with multiplier) ----------
export function startTension() {
  if (playCustom("tension")) return;
  if (tension || !enabled) return;
  let beat = 0;
  const tick = () => {
    playTick();
    beat++;
  };
  const id = window.setInterval(tick, 700);
  tension = { interval: id };
}

export function updateTension(multiplier: number) {
  if (!tension) return;
  // Adjust tick speed: faster as multiplier grows
  const interval = Math.max(120, 700 - (multiplier - 1) * 90);
  window.clearInterval(tension.interval);
  tension.interval = window.setInterval(playTick, interval);
}

export function stopTension() {
  stopCustomLoop("tension");
  if (!tension) return;
  window.clearInterval(tension.interval);
  tension = null;
}

function playTick() {
  const c = getCtx();
  if (!c || !masterGain || !enabled) return;
  const t = c.currentTime;
  const osc = c.createOscillator();
  osc.type = "sine";
  osc.frequency.value = 90;
  const gain = c.createGain();
  gain.gain.setValueAtTime(0, t);
  gain.gain.linearRampToValueAtTime(0.08, t + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
  osc.connect(gain);
  gain.connect(masterGain);
  osc.start(t);
  osc.stop(t + 0.2);
}

// ---------- Cashout / Win ----------
export function playWin() {
  if (playCustom("cashout")) return;
  const c = getCtx();
  if (!c || !masterGain || !enabled) return;
  const t = c.currentTime;
  const notes = [880, 1175, 1568];
  notes.forEach((f, i) => {
    const osc = c.createOscillator();
    osc.type = "triangle";
    osc.frequency.value = f;
    const gain = c.createGain();
    const start = t + i * 0.07;
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(0.18, start + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.4);
    osc.connect(gain);
    gain.connect(masterGain!);
    osc.start(start);
    osc.stop(start + 0.45);
  });
}

// ---------- Crash ----------
export function playCrash() {
  if (playCustom("crash")) return;
  const c = getCtx();
  if (!c || !masterGain || !enabled) return;
  const t = c.currentTime;
  // Noise burst
  const noise = c.createBufferSource();
  noise.buffer = makeNoiseBuffer(c, 0.6);
  const filter = c.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(2000, t);
  filter.frequency.exponentialRampToValueAtTime(120, t + 0.5);
  const gain = c.createGain();
  gain.gain.setValueAtTime(0.35, t);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  noise.start(t);
  noise.stop(t + 0.6);

  // Glitch tone drop
  const osc = c.createOscillator();
  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(440, t);
  osc.frequency.exponentialRampToValueAtTime(40, t + 0.4);
  const og = c.createGain();
  og.gain.setValueAtTime(0.18, t);
  og.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
  osc.connect(og);
  og.connect(masterGain);
  osc.start(t);
  osc.stop(t + 0.5);
}

// ---------- UI tap ----------
export function playTap() {
  if (playCustom("ui_tap")) return;
  const c = getCtx();
  if (!c || !masterGain || !enabled) return;
  const t = c.currentTime;
  const osc = c.createOscillator();
  osc.type = "square";
  osc.frequency.setValueAtTime(1200, t);
  osc.frequency.exponentialRampToValueAtTime(700, t + 0.05);
  const gain = c.createGain();
  gain.gain.setValueAtTime(0.06, t);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
  osc.connect(gain);
  gain.connect(masterGain);
  osc.start(t);
  osc.stop(t + 0.08);
}