import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";

const placeBetSchema = z.object({
  roundId: z.number().int(),
  panel: z.union([z.literal(1), z.literal(2)]),
  amount: z.number().positive().max(100000),
  autoCashout: z.number().min(1.01).max(1000).nullable().optional(),
});

const cashoutSchema = z.object({ betId: z.number().int() });
const withdrawalSchema = z.object({
  amount: z.number().positive(),
  currency: z.enum(["INR", "USD"]),
  upiId: z.string().min(3).max(100),
  accountName: z.string().max(100).optional().nullable(),
});
const reviewSchema = z.object({
  requestId: z.string().uuid(),
  approve: z.boolean(),
  adminNote: z.string().max(500).optional().nullable(),
});
const adminClaimSchema = z.object({ email: z.string().email() });
const depositSchema = z.object({
  amount: z.number().positive(),
  currency: z.enum(["INR", "USD"]),
  utr: z.string().min(6).max(50),
  screenshotUrl: z.string().url().optional().nullable(),
});
const promoSchema = z.object({
  code: z.string().trim().min(1).max(50),
});

export function computeMultiplier(elapsedMs: number) {
  const t = elapsedMs / 1000;
  return Math.max(1, 1 + 0.05 * t + 0.05 * Math.pow(t, 1.7));
}

export async function getCurrentRound() {
  const { data, error } = await supabase.rpc("advance_game_round");
  if (error) throw error;
  return (data ?? { round: null, recent: [], serverTime: Date.now() }) as {
    round: {
      id: number;
      phase: "waiting" | "flying" | "crashed";
      crash_at: number;
      flying_started_at: string | null;
      crashed_at: string | null;
      waiting_until: string;
    } | null;
    recent: { id: number; crash_at: number }[];
    serverTime: number;
  };
}

export async function placeBet(input: unknown) {
  const data = placeBetSchema.parse(input);

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, error: "Please sign in" };

  const { data: round } = await supabase.from("game_rounds").select("*").eq("id", data.roundId).single();
  if (!round) return { ok: false, error: "Round not found" };
  if (round.phase !== "waiting") return { ok: false, error: "Betting closed" };

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  if (!profile) return { ok: false, error: "Profile not found" };

  const isINR = profile.currency === "INR";
  const balance = Number(isINR ? profile.balance_inr : profile.balance_usd);
  if (balance < data.amount) return { ok: false, error: "Insufficient balance" };

  const { error: updErr } = await supabase
    .from("profiles")
    .update(isINR ? { balance_inr: balance - data.amount } : { balance_usd: balance - data.amount })
    .eq("id", user.id);
  if (updErr) return { ok: false, error: updErr.message };

  const { error: betErr, data: bet } = await supabase
    .from("bets")
    .insert({
      round_id: data.roundId,
      user_id: user.id,
      username: profile.username,
      avatar_seed: profile.avatar_seed,
      panel: data.panel,
      amount: data.amount,
      currency: profile.currency,
      auto_cashout: data.autoCashout ?? null,
      status: "pending",
    })
    .select("*")
    .single();

  if (betErr) {
    await supabase
      .from("profiles")
      .update(isINR ? { balance_inr: balance } : { balance_usd: balance })
      .eq("id", user.id);
    return { ok: false, error: betErr.message };
  }

  return { ok: true, bet };
}

export async function cashout(input: unknown) {
  const data = cashoutSchema.parse(input);
  const { data: result, error } = await supabase.rpc("player_cashout", {
    _bet_id: data.betId,
  });
  if (error) return { ok: false, error: error.message };
  return (result ?? { ok: false, error: "Cashout failed" }) as {
    ok: boolean;
    multiplier?: number;
    win?: number;
    error?: string;
  };
}

export async function createWithdrawalRequest(input: unknown) {
  const data = withdrawalSchema.parse(input);
  const { data: result, error } = await supabase.rpc("create_withdrawal_request", {
    _amount: data.amount,
    _currency: data.currency,
    _upi_id: data.upiId,
    _account_name: data.accountName ?? undefined,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true, request: result };
}

export async function reviewDepositRequest(input: unknown) {
  const data = reviewSchema.parse(input);
  const { data: result, error } = await supabase.rpc("admin_review_deposit", {
    _request_id: data.requestId,
    _approve: data.approve,
    _admin_note: data.adminNote ?? undefined,
  });
  if (error) return { ok: false, error: error.message };
  if (!result) return { ok: false, error: "Request not found or already reviewed" };
  return { ok: true };
}

export async function reviewWithdrawalRequest(input: unknown) {
  const data = reviewSchema.parse(input);
  const { data: result, error } = await supabase.rpc("admin_review_withdrawal", {
    _request_id: data.requestId,
    _approve: data.approve,
    _admin_note: data.adminNote ?? undefined,
  });
  if (error) return { ok: false, error: error.message };
  if (!result) return { ok: false, error: "Request not found or already reviewed" };
  return { ok: true };
}

export async function claimInitialAdmin(input: unknown) {
  const data = adminClaimSchema.parse(input);
  const { data: result, error } = await supabase.rpc("claim_initial_admin", {
    admin_email: data.email,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: Boolean(result) };
}

export async function createDepositRequest(input: unknown) {
  const data = depositSchema.parse(input);
  const { data: result, error } = await supabase.rpc("create_deposit_request", {
    _amount: data.amount,
    _currency: data.currency,
    _utr: data.utr,
    _screenshot_url: data.screenshotUrl ?? undefined,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true, request: result };
}

export async function redeemPromoCode(input: unknown) {
  const data = promoSchema.parse(input);
  const { data: result, error } = await supabase.rpc("redeem_promo_code", {
    _code: data.code,
  });
  if (error) return { ok: false, error: error.message };
  return (result ?? { ok: false, error: "Failed" }) as {
    ok: boolean;
    amount?: number;
    currency?: string;
    error?: string;
  };
}
