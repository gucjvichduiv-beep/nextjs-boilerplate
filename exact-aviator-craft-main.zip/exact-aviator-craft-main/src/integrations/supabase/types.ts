export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_payment_settings: {
        Row: {
          created_at: string
          deposit_note: string | null
          id: string
          is_active: boolean
          qr_image_url: string | null
          updated_at: string
          updated_by: string | null
          upi_id: string | null
          upi_name: string | null
          withdrawal_note: string | null
        }
        Insert: {
          created_at?: string
          deposit_note?: string | null
          id?: string
          is_active?: boolean
          qr_image_url?: string | null
          updated_at?: string
          updated_by?: string | null
          upi_id?: string | null
          upi_name?: string | null
          withdrawal_note?: string | null
        }
        Update: {
          created_at?: string
          deposit_note?: string | null
          id?: string
          is_active?: boolean
          qr_image_url?: string | null
          updated_at?: string
          updated_by?: string | null
          upi_id?: string | null
          upi_name?: string | null
          withdrawal_note?: string | null
        }
        Relationships: []
      }
      bets: {
        Row: {
          amount: number
          auto_cashout: number | null
          avatar_seed: string
          cashout_at: number | null
          created_at: string
          currency: string
          id: number
          panel: number
          round_id: number
          status: string
          user_id: string
          username: string
          win_amount: number | null
        }
        Insert: {
          amount: number
          auto_cashout?: number | null
          avatar_seed?: string
          cashout_at?: number | null
          created_at?: string
          currency: string
          id?: number
          panel: number
          round_id: number
          status?: string
          user_id: string
          username: string
          win_amount?: number | null
        }
        Update: {
          amount?: number
          auto_cashout?: number | null
          avatar_seed?: string
          cashout_at?: number | null
          created_at?: string
          currency?: string
          id?: number
          panel?: number
          round_id?: number
          status?: string
          user_id?: string
          username?: string
          win_amount?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "bets_round_id_fkey"
            columns: ["round_id"]
            isOneToOne: false
            referencedRelation: "game_rounds"
            referencedColumns: ["id"]
          },
        ]
      }
      deposit_requests: {
        Row: {
          admin_note: string | null
          amount: number
          created_at: string
          currency: string
          id: string
          reviewed_at: string | null
          reviewed_by: string | null
          screenshot_url: string | null
          status: Database["public"]["Enums"]["wallet_request_status"]
          updated_at: string
          user_id: string
          utr: string
        }
        Insert: {
          admin_note?: string | null
          amount: number
          created_at?: string
          currency?: string
          id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          screenshot_url?: string | null
          status?: Database["public"]["Enums"]["wallet_request_status"]
          updated_at?: string
          user_id: string
          utr: string
        }
        Update: {
          admin_note?: string | null
          amount?: number
          created_at?: string
          currency?: string
          id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          screenshot_url?: string | null
          status?: Database["public"]["Enums"]["wallet_request_status"]
          updated_at?: string
          user_id?: string
          utr?: string
        }
        Relationships: []
      }
      game_rounds: {
        Row: {
          crash_at: number
          crashed_at: string | null
          created_at: string
          flying_started_at: string | null
          id: number
          phase: string
          waiting_until: string
        }
        Insert: {
          crash_at: number
          crashed_at?: string | null
          created_at?: string
          flying_started_at?: string | null
          id?: number
          phase: string
          waiting_until: string
        }
        Update: {
          crash_at?: number
          crashed_at?: string | null
          created_at?: string
          flying_started_at?: string | null
          id?: number
          phase?: string
          waiting_until?: string
        }
        Relationships: []
      }
      game_settings: {
        Row: {
          created_at: string
          fixed_crash: number | null
          id: string
          instant_crash_chance: number
          is_active: boolean
          max_crash: number
          min_crash: number
          mode: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          fixed_crash?: number | null
          id?: string
          instant_crash_chance?: number
          is_active?: boolean
          max_crash?: number
          min_crash?: number
          mode?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          fixed_crash?: number | null
          id?: string
          instant_crash_chance?: number
          is_active?: boolean
          max_crash?: number
          min_crash?: number
          mode?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      game_sounds: {
        Row: {
          audio_url: string | null
          created_at: string
          event_key: string
          id: string
          is_enabled: boolean
          label: string
          loop: boolean
          updated_at: string
          updated_by: string | null
          volume: number
        }
        Insert: {
          audio_url?: string | null
          created_at?: string
          event_key: string
          id?: string
          is_enabled?: boolean
          label: string
          loop?: boolean
          updated_at?: string
          updated_by?: string | null
          volume?: number
        }
        Update: {
          audio_url?: string | null
          created_at?: string
          event_key?: string
          id?: string
          is_enabled?: boolean
          label?: string
          loop?: boolean
          updated_at?: string
          updated_by?: string | null
          volume?: number
        }
        Relationships: []
      }
      plane_settings: {
        Row: {
          accent_color: string
          body_color: string
          created_at: string
          id: string
          image_url: string | null
          is_active: boolean
          scale: number
          style: string
          trail_color: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          accent_color?: string
          body_color?: string
          created_at?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          scale?: number
          style?: string
          trail_color?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          accent_color?: string
          body_color?: string
          created_at?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          scale?: number
          style?: string
          trail_color?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_seed: string
          balance_inr: number
          balance_usd: number
          created_at: string
          currency: string
          id: string
          is_guest: boolean
          username: string
        }
        Insert: {
          avatar_seed?: string
          balance_inr?: number
          balance_usd?: number
          created_at?: string
          currency?: string
          id: string
          is_guest?: boolean
          username: string
        }
        Update: {
          avatar_seed?: string
          balance_inr?: number
          balance_usd?: number
          created_at?: string
          currency?: string
          id?: string
          is_guest?: boolean
          username?: string
        }
        Relationships: []
      }
      promo_code_redemptions: {
        Row: {
          amount: number
          created_at: string
          currency: string
          id: string
          promo_code_id: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          currency: string
          id?: string
          promo_code_id: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          id?: string
          promo_code_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_code_redemptions_promo_code_id_fkey"
            columns: ["promo_code_id"]
            isOneToOne: false
            referencedRelation: "promo_codes"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_codes: {
        Row: {
          amount: number
          code: string
          created_at: string
          created_by: string | null
          currency: string
          expires_at: string | null
          id: string
          is_active: boolean
          max_per_user: number
          max_total_uses: number | null
          note: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          code: string
          created_at?: string
          created_by?: string | null
          currency?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_per_user?: number
          max_total_uses?: number | null
          note?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          code?: string
          created_at?: string
          created_by?: string | null
          currency?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_per_user?: number
          max_total_uses?: number | null
          note?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      withdrawal_requests: {
        Row: {
          account_name: string | null
          admin_note: string | null
          amount: number
          created_at: string
          currency: string
          id: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["wallet_request_status"]
          updated_at: string
          upi_id: string
          user_id: string
        }
        Insert: {
          account_name?: string | null
          admin_note?: string | null
          amount: number
          created_at?: string
          currency?: string
          id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["wallet_request_status"]
          updated_at?: string
          upi_id: string
          user_id: string
        }
        Update: {
          account_name?: string | null
          admin_note?: string | null
          amount?: number
          created_at?: string
          currency?: string
          id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["wallet_request_status"]
          updated_at?: string
          upi_id?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_adjust_balance: {
        Args: { _currency: string; _delta: number; _user_id: string }
        Returns: Json
      }
      admin_exists: { Args: never; Returns: boolean }
      admin_list_users: {
        Args: never
        Returns: {
          balance_inr: number
          balance_usd: number
          created_at: string
          currency: string
          email: string
          is_admin: boolean
          is_guest: boolean
          user_id: string
          username: string
        }[]
      }
      admin_review_deposit: {
        Args: { _admin_note?: string; _approve: boolean; _request_id: string }
        Returns: boolean
      }
      admin_review_withdrawal: {
        Args: { _admin_note?: string; _approve: boolean; _request_id: string }
        Returns: boolean
      }
      advance_game_round: { Args: never; Returns: Json }
      claim_initial_admin: { Args: { admin_email: string }; Returns: boolean }
      compute_multiplier_db: { Args: { elapsed_ms: number }; Returns: number }
      create_deposit_request: {
        Args: {
          _amount: number
          _currency: string
          _screenshot_url?: string
          _utr: string
        }
        Returns: Json
      }
      create_withdrawal_request: {
        Args: {
          _account_name?: string
          _amount: number
          _currency: string
          _upi_id: string
        }
        Returns: Json
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      mark_round_losses: { Args: { _round_id: number }; Returns: undefined }
      pick_next_crash: { Args: never; Returns: number }
      player_cashout: { Args: { _bet_id: number }; Returns: Json }
      promote_user_to_admin: { Args: { _email: string }; Returns: boolean }
      redeem_promo_code: { Args: { _code: string }; Returns: Json }
      revoke_admin: { Args: { _email: string }; Returns: boolean }
      settle_auto_cashouts: {
        Args: { _current_mult: number; _round_id: number }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin"
      wallet_request_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin"],
      wallet_request_status: ["pending", "approved", "rejected"],
    },
  },
} as const
