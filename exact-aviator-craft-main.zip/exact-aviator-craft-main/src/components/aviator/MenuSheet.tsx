import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/lib/auth-context";
import { useEffect, useState } from "react";
import { redeemPromoCode } from "@/server/game";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Gift, Ticket } from "lucide-react";

export function MenuSheet({ open, onOpenChange, initialPromoOpen = false }: { open: boolean; onOpenChange: (o: boolean) => void; initialPromoOpen?: boolean }) {
  const { user, profile, signOut, setCurrency, refreshProfile } = useAuth();
  const [promoOpen, setPromoOpen] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [redeeming, setRedeeming] = useState(false);
  type RedemptionRow = {
    id: string;
    amount: number;
    currency: string;
    created_at: string;
    promo_codes: { code: string } | null;
  };
  const [history, setHistory] = useState<RedemptionRow[]>([]);

  const loadHistory = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("promo_code_redemptions")
      .select("id, amount, currency, created_at, promo_codes(code)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(10);
    setHistory((data ?? []) as RedemptionRow[]);
  };

  useEffect(() => {
    if (promoOpen) void loadHistory();
  }, [promoOpen, user]);

  useEffect(() => {
    if (open && initialPromoOpen) setPromoOpen(true);
  }, [open, initialPromoOpen]);

  const claim = async () => {
    if (!promoCode.trim()) return;
    setRedeeming(true);
    try {
      const res = await redeemPromoCode({ code: promoCode.trim() });
      if (!res.ok) {
        toast.error(res.error ?? "Could not claim");
        return;
      }
      toast.success(`+${Number(res.amount).toFixed(2)} ${res.currency} credited!`);
      setPromoCode("");
      await Promise.all([refreshProfile(), loadHistory()]);
    } finally {
      setRedeeming(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="bg-[#0f1012] border-[#2c2d31] text-foreground w-[320px]">
        <SheetHeader>
          <SheetTitle className="text-foreground">Account</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-4">
          <div className="bg-[#1b1c1f] rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-1">Account</div>
            <div className="font-medium">{profile?.username ?? "—"}</div>
          </div>

          <div className="bg-[#1b1c1f] rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-2">Currency</div>
            <div className="flex gap-2">
              {(["INR", "USD"] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => setCurrency(c)}
                  className={`flex-1 py-2 rounded-md text-sm font-medium ${
                    profile?.currency === c
                      ? "bg-[#e50539] text-white"
                      : "bg-[#2c2d31] text-muted-foreground"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              Balance: {profile ? (profile.currency === "INR" ? Number(profile.balance_inr).toFixed(2) : Number(profile.balance_usd).toFixed(2)) : "0"} {profile?.currency}
            </div>
          </div>

          <button
            onClick={() => setPromoOpen((v) => !v)}
            className="w-full bg-gradient-to-r from-[#e50539] to-[#b8042f] hover:from-[#d40434] hover:to-[#a80329] rounded-lg p-3 flex items-center gap-3 text-left transition"
          >
            <Gift className="w-5 h-5 text-white" />
            <div className="flex-1">
              <div className="text-sm font-bold text-white">Claim Promo Code</div>
              <div className="text-[10px] text-white/80">Enter code to get free credits</div>
            </div>
          </button>

          {promoOpen && (
            <div className="bg-[#1b1c1f] rounded-lg p-3 space-y-3">
              <div className="flex items-center gap-2">
                <Ticket className="w-4 h-4 text-[#28a909]" />
                <span className="text-sm font-semibold">Enter promo code</span>
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="PROMO123"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                  className="bg-[#0f1012] border-[#2c2d31] uppercase font-mono"
                  maxLength={50}
                />
                <Button
                  onClick={claim}
                  disabled={redeeming || !promoCode.trim()}
                  className="bg-[#28a909] hover:bg-[#23990a]"
                >
                  {redeeming ? "..." : "Claim"}
                </Button>
              </div>
              {history.length > 0 && (
                <div className="space-y-1 pt-2 border-t border-[#2c2d31]">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wide">Recent claims</div>
                  {history.map((h) => (
                    <div key={h.id} className="flex justify-between text-xs">
                      <span className="font-mono text-muted-foreground">{h.promo_codes?.code ?? "—"}</span>
                      <span className="text-[#28a909] font-semibold">+{Number(h.amount).toFixed(2)} {h.currency}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <Button onClick={signOut} variant="outline" className="w-full">
            Log out
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}