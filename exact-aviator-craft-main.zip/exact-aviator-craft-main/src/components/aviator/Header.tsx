import { MoreVertical, Wallet as WalletIcon, Gift } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { formatMoney } from "@/lib/format";
import { setSoundEnabled, isSoundEnabled } from "@/lib/sound";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link } from "@tanstack/react-router";

export function Header({
  onMenuClick,
  onWalletClick,
  onWalletHistoryClick,
  onPromoClick,
}: {
  onMenuClick: () => void;
  onWalletClick: () => void;
  onWalletHistoryClick: () => void;
  onPromoClick: () => void;
}) {
  const { profile, isAdmin } = useAuth();
  const [soundOn, setSoundOn] = useState(isSoundEnabled());
  const balance = profile
    ? profile.currency === "INR"
      ? Number(profile.balance_inr)
      : Number(profile.balance_usd)
    : 0;
  const currency = profile?.currency ?? "INR";

  return (
    <header className="flex items-center justify-between px-4 py-3 bg-[#0f1012] border-b border-[#1f2024]">
      <div className="flex items-center gap-2">
        <span
          className="text-[#e50539] font-extrabold italic text-3xl tracking-tight"
          style={{ fontFamily: "'Pacifico', 'Brush Script MT', cursive" }}
        >
          Aviator
        </span>
        <svg width="28" height="14" viewBox="0 0 28 14" className="text-[#e50539]">
          <path
            fill="currentColor"
            d="M2 8 L18 4 L22 1 L24 5 L26 5 L24 8 L18 8 L14 13 L10 13 L12 9 Z"
          />
        </svg>
      </div>
      <div className="flex items-center gap-3">
        <div className="text-right">
          <span className="text-[#28a909] font-bold text-xl tracking-tight">
            {formatMoney(balance, currency)}
          </span>
          <span className="text-muted-foreground text-sm ml-1">{currency}</span>
        </div>
        <button
          onClick={onWalletClick}
          aria-label="Wallet"
          className="flex items-center gap-1 bg-[#28a909] hover:bg-[#23990a] text-white text-xs font-semibold px-2.5 py-1.5 rounded-md"
        >
          <WalletIcon className="w-3.5 h-3.5" />
          Deposit
        </button>
        <div className="w-px h-6 bg-[#2c2d31]" />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              aria-label="More"
              className="text-foreground/80 hover:text-foreground p-1"
            >
              <MoreVertical className="w-6 h-6" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-[#1b1c1f] border-[#2c2d31] text-foreground">
            <DropdownMenuItem onClick={onWalletClick}>Deposit</DropdownMenuItem>
            <DropdownMenuItem onClick={onWalletHistoryClick}>Withdraw</DropdownMenuItem>
            <DropdownMenuItem onClick={onWalletHistoryClick}>Wallet History</DropdownMenuItem>
            <DropdownMenuSeparator className="bg-[#2c2d31]" />
            <DropdownMenuItem onClick={onPromoClick} className="text-[#28a909] focus:text-[#28a909]">
              <Gift className="w-4 h-4 mr-2" />
              Claim Promo Code
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-[#2c2d31]" />
            <DropdownMenuItem
              onClick={(e) => {
                e.preventDefault();
                const next = !soundOn;
                setSoundOn(next);
                setSoundEnabled(next);
              }}
            >
              Sound: {soundOn ? "On" : "Off"}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onMenuClick}>Account & Settings</DropdownMenuItem>
            {isAdmin && (
              <DropdownMenuItem asChild>
                <Link to="/admin">Admin Panel</Link>
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}