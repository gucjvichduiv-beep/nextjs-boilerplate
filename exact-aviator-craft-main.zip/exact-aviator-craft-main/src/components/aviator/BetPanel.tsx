import { useEffect, useState } from "react";
import { Minus, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth-context";
import { placeBet, cashout } from "@/server/game";
import { toast } from "sonner";
import { playWin, playTap } from "@/lib/sound";

type Phase = "waiting" | "flying" | "crashed";

type Props = {
  panel: 1 | 2;
  phase: Phase;
  roundId: number | null;
  liveMultiplier: number;
  pendingBet: { id: number; amount: number; auto_cashout: number | null } | null;
};

const QUICK = [10, 50, 100, 500];

export function BetPanel({ panel, phase, roundId, liveMultiplier, pendingBet }: Props) {
  const { profile } = useAuth();

  const [tab, setTab] = useState<"bet" | "auto">("bet");
  const [amount, setAmount] = useState<number>(100);
  const [autoCashAt, setAutoCashAt] = useState<number>(2);
  const [autoEnabled, setAutoEnabled] = useState(false);
  const [pendingNext, setPendingNext] = useState(false); // queued bet for next round
  const [submitting, setSubmitting] = useState(false);

  const currency = profile?.currency ?? "INR";

  // Auto place queued bet when waiting starts
  useEffect(() => {
    if (phase === "waiting" && pendingNext && roundId && !pendingBet && !submitting) {
      doPlaceBet();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, roundId, pendingNext]);

  // Auto cashout handler
  useEffect(() => {
    if (
      phase === "flying" &&
      pendingBet &&
      pendingBet.auto_cashout &&
      liveMultiplier >= pendingBet.auto_cashout
    ) {
      doCashout();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [liveMultiplier, phase, pendingBet]);

  const adjust = (delta: number) => {
    setAmount((a) => Math.max(1, +(a + delta).toFixed(2)));
  };

  const doPlaceBet = async () => {
    if (!roundId) return;
    setSubmitting(true);
    try {
      const res = await placeBet({
        roundId,
        panel,
        amount,
        autoCashout: tab === "auto" && autoEnabled ? autoCashAt : null,
      });
      if (!res.ok) {
        toast.error(res.error ?? "Bet failed");
        setPendingNext(false);
      }
    } catch (e) {
      toast.error("Bet failed");
    } finally {
      setSubmitting(false);
    }
  };

  const doCashout = async () => {
    if (!pendingBet) return;
    setSubmitting(true);
    try {
      const res = await cashout({ betId: pendingBet.id });
      if (res.ok) {
        playWin();
        toast.success(`Won ${(res.win ?? 0).toFixed(2)} ${currency} @ ${res.multiplier?.toFixed(2)}x`);
      } else {
        toast.error(res.error ?? "Cashout failed");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const onMainClick = () => {
    playTap();
    if (pendingBet && phase === "flying") {
      doCashout();
      return;
    }
    if (pendingBet && phase === "waiting") {
      // Cancel: not implemented (refund); keep simple
      return;
    }
    if (phase === "waiting" && roundId) {
      doPlaceBet();
      return;
    }
    // Queue for next round
    setPendingNext((p) => !p);
  };

  // Determine button state
  const isCashoutMode = pendingBet && phase === "flying";
  const liveWin = isCashoutMode ? Number(pendingBet.amount) * liveMultiplier : 0;

  let btnLabel: React.ReactNode;
  let btnClass = "bg-[#28a909] hover:bg-[#23990a] shadow-[0_0_14px_rgba(40,169,9,0.55)]";

  if (isCashoutMode) {
    btnLabel = (
      <div className="flex flex-col items-center leading-tight">
        <span className="text-base font-semibold">CASH OUT</span>
        <span className="text-2xl font-bold mt-0.5">
          {liveWin.toFixed(2)} <span className="text-base font-medium">{currency}</span>
        </span>
      </div>
    );
    btnClass = "bg-[#d07206] hover:bg-[#b86205] shadow-[0_0_14px_rgba(208,114,6,0.55)]";
  } else if (pendingBet && phase === "waiting") {
    btnLabel = (
      <div className="flex flex-col items-center leading-tight">
        <span className="text-base font-semibold">CANCEL</span>
        <span className="text-sm">Waiting for round…</span>
      </div>
    );
    btnClass = "bg-[#e50539] hover:bg-[#c20531]";
  } else if (pendingNext) {
    btnLabel = (
      <div className="flex flex-col items-center leading-tight">
        <span className="text-base font-semibold">CANCEL</span>
        <span className="text-sm">Bet queued for next round</span>
      </div>
    );
    btnClass = "bg-[#e50539] hover:bg-[#c20531]";
  } else {
    btnLabel = (
      <div className="flex flex-col items-center leading-tight">
        <span className="text-base font-semibold">BET</span>
        <span className="text-2xl font-bold mt-0.5">
          {amount.toFixed(2)} <span className="text-base font-medium">{currency}</span>
        </span>
      </div>
    );
  }

  const isCashoutHighlight = isCashoutMode;

  return (
    <div
      className={cn(
        "rounded-xl p-3 transition-colors",
        isCashoutHighlight
          ? "bg-[#3a1414] ring-2 ring-[#e50539]"
          : "bg-[#1b1c1f] ring-1 ring-[#2c2d31]",
      )}
    >
      {/* Bet/Auto pill tabs */}
      <div className="flex justify-center mb-3">
        <div className="flex bg-[#0f1012] rounded-full p-1 w-fit">
          <button
            onClick={() => setTab("bet")}
            className={cn(
              "px-6 py-1.5 rounded-full text-sm font-medium transition-colors",
              tab === "bet" ? "bg-[#2c2d31] text-foreground" : "text-muted-foreground",
            )}
          >
            Bet
          </button>
          <button
            onClick={() => setTab("auto")}
            className={cn(
              "px-6 py-1.5 rounded-full text-sm font-medium transition-colors",
              tab === "auto" ? "bg-[#2c2d31] text-foreground" : "text-muted-foreground",
            )}
          >
            Auto
          </button>
        </div>
      </div>

      <div className="grid grid-cols-[auto_1fr] gap-3 items-stretch">
        {/* Left: amount control */}
        <div className="flex flex-col items-center gap-2">
          <div className="flex items-center gap-1 bg-[#0f1012] rounded-full px-2 py-1.5">
            <button
              onClick={() => adjust(-1)}
              aria-label="Decrease"
              className="w-7 h-7 flex items-center justify-center rounded-full bg-[#2c2d31] text-foreground/80"
            >
              <Minus className="w-4 h-4" />
            </button>
            <input
              value={amount.toFixed(1)}
              onChange={(e) => {
                const v = parseFloat(e.target.value);
                if (!isNaN(v)) setAmount(Math.max(1, v));
              }}
              className="w-16 bg-transparent text-center font-bold text-foreground outline-none text-base"
              inputMode="decimal"
            />
            <button
              onClick={() => adjust(1)}
              aria-label="Increase"
              className="w-7 h-7 flex items-center justify-center rounded-full bg-[#2c2d31] text-foreground/80"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {QUICK.map((q) => (
              <button
                key={q}
                onClick={() => setAmount(q)}
                className={cn(
                  "px-3 py-1 rounded-full text-xs font-medium border",
                  isCashoutHighlight
                    ? "bg-[#5a1f1f] border-[#7a2a2a] text-foreground"
                    : "bg-[#0f1012] border-[#2c2d31] text-muted-foreground hover:text-foreground",
                )}
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Right: main button + auto controls */}
        <div className="flex flex-col gap-2">
          {tab === "auto" && (
            <div className="flex items-center justify-between bg-[#0f1012] rounded-lg px-3 py-1.5 text-sm">
              <label className="flex items-center gap-2 text-muted-foreground">
                <input
                  type="checkbox"
                  checked={autoEnabled}
                  onChange={(e) => setAutoEnabled(e.target.checked)}
                  className="accent-[#28a909]"
                />
                Auto cash out
              </label>
              <div className="flex items-center gap-1">
                <input
                  value={autoCashAt}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!isNaN(v)) setAutoCashAt(Math.max(1.01, v));
                  }}
                  className="w-14 bg-[#1b1c1f] rounded px-2 py-0.5 text-center text-foreground outline-none"
                  inputMode="decimal"
                />
                <span className="text-muted-foreground">x</span>
              </div>
            </div>
          )}
          <button
            disabled={submitting}
            onClick={onMainClick}
            className={cn(
              "rounded-xl text-white font-bold flex items-center justify-center transition-all flex-1 min-h-[88px] px-4",
              btnClass,
              submitting && "opacity-70",
            )}
          >
            {btnLabel}
          </button>
        </div>
      </div>
    </div>
  );
}