import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { multiplierColor } from "@/lib/format";

type Bet = {
  id: number;
  username: string;
  avatar_seed: string;
  amount: number;
  currency: string;
  cashout_at: number | null;
  win_amount: number | null;
  status: "pending" | "won" | "lost";
  round_id: number;
};

type Tab = "all" | "previous" | "top";

export function BetsList({ currentRoundId }: { currentRoundId: number | null }) {
  const [tab, setTab] = useState<Tab>("all");
  const [allBets, setAllBets] = useState<Bet[]>([]);
  const [prevBets, setPrevBets] = useState<Bet[]>([]);
  const [topBets, setTopBets] = useState<Bet[]>([]);

  // Load + subscribe to current round bets
  useEffect(() => {
    if (!currentRoundId) return;
    let cancelled = false;
    supabase
      .from("bets")
      .select("*")
      .eq("round_id", currentRoundId)
      .order("id", { ascending: false })
      .then(({ data }) => {
        if (!cancelled && data) setAllBets(data as Bet[]);
      });

    const ch = supabase
      .channel("bets-current-" + currentRoundId)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bets", filter: `round_id=eq.${currentRoundId}` },
        (payload) => {
          setAllBets((prev) => {
            if (payload.eventType === "INSERT") return [payload.new as Bet, ...prev];
            if (payload.eventType === "UPDATE")
              return prev.map((b) => (b.id === (payload.new as Bet).id ? (payload.new as Bet) : b));
            return prev;
          });
        },
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(ch);
    };
  }, [currentRoundId]);

  // Load previous round + top wins on tab change
  useEffect(() => {
    if (tab === "previous") {
      supabase
        .from("bets")
        .select("*")
        .order("id", { ascending: false })
        .lt("round_id", currentRoundId ?? 999999999)
        .limit(50)
        .then(({ data }) => {
          if (data) setPrevBets(data as Bet[]);
        });
    } else if (tab === "top") {
      supabase
        .from("bets")
        .select("*")
        .eq("status", "won")
        .order("win_amount", { ascending: false })
        .limit(50)
        .then(({ data }) => {
          if (data) setTopBets(data as Bet[]);
        });
    }
  }, [tab, currentRoundId]);

  const list = tab === "all" ? allBets : tab === "previous" ? prevBets : topBets;
  const totalBets = allBets.length;
  const totalWin = allBets.reduce((s, b) => s + Number(b.win_amount ?? 0), 0);

  return (
    <div className="bg-[#1b1c1f] rounded-xl p-3 mt-3">
      <div className="flex bg-[#0f1012] rounded-full p-1 mb-3">
        {(["all", "previous", "top"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "flex-1 py-1.5 rounded-full text-sm font-medium capitalize transition-colors",
              tab === t ? "bg-[#2c2d31] text-foreground" : "text-muted-foreground",
            )}
          >
            {t === "all" ? "All Bets" : t}
          </button>
        ))}
      </div>

      {tab === "all" && (
        <div className="flex items-center justify-between mb-2 px-1">
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="w-6 h-6 rounded-full bg-gradient-to-br from-[#3a3b40] to-[#1b1c1f] border border-[#0f1012]"
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">
              {totalBets}/{Math.max(totalBets, 100)} <span>Bets</span>
            </span>
          </div>
          <div className="text-right">
            <div className="font-bold text-foreground">{totalWin.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground">Total win</div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-[1.4fr_1fr_0.8fr_1fr] gap-2 text-xs text-muted-foreground px-2 py-1 border-b border-[#2c2d31]">
        <span>Player</span>
        <span className="text-right">Bet</span>
        <span className="text-right">x</span>
        <span className="text-right">Win</span>
      </div>

      <div className="max-h-[260px] overflow-y-auto">
        {list.length === 0 && (
          <div className="text-center text-muted-foreground py-6 text-sm">No bets yet</div>
        )}
        {list.map((b) => {
          const won = b.status === "won";
          return (
            <div
              key={b.id}
              className={cn(
                "grid grid-cols-[1.4fr_1fr_0.8fr_1fr] gap-2 items-center px-2 py-2 text-sm border-b border-[#2c2d31]/40",
                won && "bg-[#0d1f0a]",
              )}
            >
              <div className="flex items-center gap-2 min-w-0">
                <div
                  className="w-7 h-7 rounded-full shrink-0"
                  style={{
                    background: `linear-gradient(135deg, hsl(${parseInt(b.avatar_seed.slice(0, 4), 16) % 360},60%,55%), #1b1c1f)`,
                  }}
                />
                <span className="truncate text-foreground/90">
                  {b.username.slice(0, 1)}***{b.username.slice(-1)}
                </span>
              </div>
              <span className="text-right text-foreground/80">{Number(b.amount).toFixed(2)}</span>
              <span className={cn("text-right font-medium", b.cashout_at ? multiplierColor(Number(b.cashout_at)) : "text-muted-foreground")}>
                {b.cashout_at ? Number(b.cashout_at).toFixed(2) + "x" : ""}
              </span>
              <span className={cn("text-right font-medium", won ? "text-[#28a909]" : "text-muted-foreground")}>
                {b.win_amount ? Number(b.win_amount).toFixed(2) : ""}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}