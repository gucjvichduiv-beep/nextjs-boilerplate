import { useEffect, useRef, useState } from "react";
import planeImg from "@/assets/plane.png";
import { supabase } from "@/integrations/supabase/client";

type Props = {
  phase: "waiting" | "flying" | "crashed";
  multiplier: number;
  countdownSec: number;
  crashedMultiplier: number | null;
};

type PlaneSettings = {
  body_color: string;
  accent_color: string;
  trail_color: string;
  style: string;
  scale: number;
  image_url: string | null;
};

const DEFAULTS: PlaneSettings = {
  body_color: "#e50539",
  accent_color: "#ffffff",
  trail_color: "#e50539",
  style: "classic",
  scale: 1,
  image_url: null,
};

function hexToRgba(hex: string, alpha: number): string {
  const h = hex.replace("#", "");
  const v = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(v, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}

function drawPlane(ctx: CanvasRenderingContext2D, size: number, s: PlaneSettings) {
  // Custom uploaded image takes priority
  const customImg = customImageCache.get(s.image_url ?? "");
  if (s.image_url && customImg && customImg.complete && customImg.naturalWidth > 0) {
    const ratio = customImg.naturalHeight / customImg.naturalWidth;
    const w = size * 1.6;
    const h = w * ratio;
    ctx.drawImage(customImg, -w / 2, -h / 2, w, h);
    return;
  }
  // Emoji styles render with a single character
  const emojiMap: Record<string, string> = {
    rocket: "🚀",
    jet: "✈️",
    helicopter: "🚁",
    ufo: "🛸",
    car: "🏎️",
  };
  if (emojiMap[s.style]) {
    ctx.font = `${size}px sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(emojiMap[s.style], 0, 0);
    return;
  }

  // Vector airplane (classic)
  const u = size / 100;
  ctx.save();
  // Body
  ctx.fillStyle = s.body_color;
  ctx.beginPath();
  ctx.moveTo(-40 * u, 0);
  ctx.lineTo(35 * u, -10 * u);
  ctx.quadraticCurveTo(50 * u, 0, 35 * u, 10 * u);
  ctx.closePath();
  ctx.fill();
  // Top wing
  ctx.beginPath();
  ctx.moveTo(-5 * u, -8 * u);
  ctx.lineTo(-25 * u, -28 * u);
  ctx.lineTo(-15 * u, -28 * u);
  ctx.lineTo(10 * u, -8 * u);
  ctx.closePath();
  ctx.fill();
  // Bottom wing
  ctx.beginPath();
  ctx.moveTo(-5 * u, 8 * u);
  ctx.lineTo(-25 * u, 28 * u);
  ctx.lineTo(-15 * u, 28 * u);
  ctx.lineTo(10 * u, 8 * u);
  ctx.closePath();
  ctx.fill();
  // Tail
  ctx.beginPath();
  ctx.moveTo(-40 * u, -2 * u);
  ctx.lineTo(-50 * u, -16 * u);
  ctx.lineTo(-42 * u, -16 * u);
  ctx.lineTo(-32 * u, -2 * u);
  ctx.closePath();
  ctx.fill();
  // Cockpit window (accent)
  ctx.fillStyle = s.accent_color;
  ctx.beginPath();
  ctx.ellipse(20 * u, -2 * u, 8 * u, 4 * u, 0, 0, Math.PI * 2);
  ctx.fill();
  // Stripe
  ctx.fillStyle = s.accent_color;
  ctx.fillRect(-30 * u, -2 * u, 55 * u, 2 * u);
  ctx.restore();
}

const customImageCache = new Map<string, HTMLImageElement>();
function ensureCustomImage(url: string | null) {
  if (!url || customImageCache.has(url)) return;
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = url;
  customImageCache.set(url, img);
}

export function PlaneCanvas({ phase, multiplier, countdownSec, crashedMultiplier }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const planeRef = useRef<HTMLImageElement | null>(null);
  const [settings, setSettings] = useState<PlaneSettings>(DEFAULTS);
  const settingsRef = useRef<PlaneSettings>(DEFAULTS);
  settingsRef.current = settings;

  useEffect(() => {
    ensureCustomImage(settings.image_url);
  }, [settings.image_url]);

  useEffect(() => {
    let mounted = true;
    void supabase
      .from("plane_settings")
      .select("body_color, accent_color, trail_color, style, scale, image_url")
      .eq("is_active", true)
      .maybeSingle()
      .then(({ data }) => {
        if (!mounted || !data) return;
        setSettings({
          body_color: data.body_color ?? DEFAULTS.body_color,
          accent_color: data.accent_color ?? DEFAULTS.accent_color,
          trail_color: data.trail_color ?? DEFAULTS.trail_color,
          style: data.style ?? DEFAULTS.style,
          scale: Number(data.scale ?? 1),
          image_url: (data as { image_url?: string | null }).image_url ?? null,
        });
      });

    const ch = supabase
      .channel("plane-settings")
      .on("postgres_changes", { event: "*", schema: "public", table: "plane_settings" }, (payload) => {
        const n = payload.new as Partial<PlaneSettings> | undefined;
        if (!n) return;
        setSettings((p) => ({
          body_color: n.body_color ?? p.body_color,
          accent_color: n.accent_color ?? p.accent_color,
          trail_color: n.trail_color ?? p.trail_color,
          style: n.style ?? p.style,
          scale: n.scale != null ? Number(n.scale) : p.scale,
          image_url: n.image_url !== undefined ? n.image_url : p.image_url,
        }));
      })
      .subscribe();
    return () => {
      mounted = false;
      supabase.removeChannel(ch);
    };
  }, []);

  useEffect(() => {
    const img = new Image();
    img.src = planeImg;
    img.onload = () => {
      planeRef.current = img;
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.floor(rect.width * dpr);
      canvas.height = Math.floor(rect.height * dpr);
    };
    resize();
    window.addEventListener("resize", resize);

    const W = () => canvas.width;
    const H = () => canvas.height;

    // Animation progress: maps multiplier to plane position 0..1
    const draw = () => {
      const w = W();
      const h = H();
      ctx.clearRect(0, 0, w, h);

      // Background sunburst
      ctx.fillStyle = "#0d0e10";
      ctx.fillRect(0, 0, w, h);
      const cx = w * 0.5;
      const cy = h * 1.1;
      const rays = 18;
      for (let i = 0; i < rays; i++) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(((Math.PI * 2) / rays) * i + (Date.now() / 6000));
        ctx.fillStyle = i % 2 === 0 ? "#15161a" : "#0d0e10";
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(w, -h * 0.05);
        ctx.lineTo(w, h * 0.05);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }

      if (phase === "waiting") {
        // Loading bar + text
        ctx.fillStyle = "#fff";
        ctx.font = `bold ${Math.floor(h * 0.07)}px sans-serif`;
        ctx.textAlign = "center";
        ctx.fillText("WAITING FOR NEXT ROUND", w / 2, h * 0.45);
        ctx.fillStyle = settingsRef.current.body_color;
        ctx.font = `bold ${Math.floor(h * 0.16)}px sans-serif`;
        ctx.fillText(countdownSec.toFixed(1) + "s", w / 2, h * 0.7);
        // Progress bar
        const barW = w * 0.6;
        const barX = (w - barW) / 2;
        const barY = h * 0.82;
        const barH = 4 * dpr;
        ctx.fillStyle = "#2c2d31";
        ctx.fillRect(barX, barY, barW, barH);
        const pct = Math.max(0, Math.min(1, 1 - countdownSec / 5.5));
        ctx.fillStyle = settingsRef.current.body_color;
        ctx.fillRect(barX, barY, barW * pct, barH);
      } else {
        const sc = settingsRef.current;
        // progress 0..1 from multiplier
        const m = phase === "crashed" && crashedMultiplier ? crashedMultiplier : multiplier;
        const t = Math.min(1, (m - 1) / 5); // saturate at 6x
        const padX = w * 0.08;
        const padY = h * 0.15;
        const startX = padX;
        const startY = h - padY;
        const endX = padX + (w - padX * 2) * (0.3 + t * 0.7);
        const endY = padY + (h - padY * 2) * (1 - (0.3 + t * 0.7));

        // Curve (quadratic)
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(endX * 0.6, startY, endX, endY);
        // Filled area under curve
        const grd = ctx.createLinearGradient(0, 0, 0, h);
        grd.addColorStop(0, hexToRgba(sc.trail_color, 0.35));
        grd.addColorStop(1, hexToRgba(sc.trail_color, 0.05));
        ctx.lineTo(endX, h);
        ctx.lineTo(startX, h);
        ctx.closePath();
        ctx.fillStyle = grd;
        ctx.fill();
        // Curve stroke
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(endX * 0.6, startY, endX, endY);
        ctx.strokeStyle = sc.trail_color;
        ctx.lineWidth = 3 * dpr;
        ctx.stroke();

        // Plane (vector, colored from admin settings)
        const ps = h * 0.35 * sc.scale;
        const px = phase === "crashed" ? endX + h * 0.2 : endX;
        const py = phase === "crashed" ? endY - h * 0.2 : endY;
        ctx.save();
        ctx.translate(px, py);
        drawPlane(ctx, ps, sc);
        ctx.restore();

        // Multiplier text
        const m2 = phase === "crashed" ? crashedMultiplier ?? multiplier : multiplier;
        ctx.fillStyle = phase === "crashed" ? sc.body_color : "#ffffff";
        ctx.font = `bold ${Math.floor(h * 0.22)}px sans-serif`;
        ctx.textAlign = "center";
        ctx.fillText(m2.toFixed(2) + "x", w / 2, h * 0.45);
        if (phase === "crashed") {
          ctx.fillStyle = sc.body_color;
          ctx.font = `bold ${Math.floor(h * 0.08)}px sans-serif`;
          ctx.fillText("FLEW AWAY!", w / 2, h * 0.6);
        }
      }
    };

    let raf = 0;
    const loop = () => {
      draw();
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(raf);
    };
  }, [phase, multiplier, countdownSec, crashedMultiplier]);

  return (
    <div className="relative w-full h-[280px] sm:h-[340px] bg-[#0d0e10] overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
}