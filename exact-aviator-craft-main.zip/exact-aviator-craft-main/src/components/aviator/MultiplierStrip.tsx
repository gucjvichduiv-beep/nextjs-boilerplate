import { History, ChevronDown } from "lucide-react";
import { multiplierColor } from "@/lib/format";

export function MultiplierStrip({ recent }: { recent: { id: number; crash_at: number }[] }) {
  return (
    <div className="flex items-center gap-3 px-3 py-2 bg-[#0f1012] border-b border-[#1f2024] overflow-hidden">
      <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide flex-1">
        {recent.length === 0 && (
          <span className="text-muted-foreground text-sm">Loading…</span>
        )}
        {recent.map((r) => {
          const m = Number(r.crash_at);
          return (
            <span
              key={r.id}
              className={`font-bold text-sm whitespace-nowrap ${multiplierColor(m)}`}
            >
              {m.toFixed(2)}x
            </span>
          );
        })}
      </div>
      <button
        aria-label="History"
        className="flex items-center gap-1 bg-[#2c2d31] rounded-full px-2 py-1 text-foreground/80 shrink-0"
      >
        <History className="w-4 h-4" />
        <ChevronDown className="w-3 h-3" />
      </button>
    </div>
  );
}