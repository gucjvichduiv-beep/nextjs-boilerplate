import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { createDepositRequest, createWithdrawalRequest } from "@/server/game";
import { toast } from "sonner";
import { Copy, Upload } from "lucide-react";

type PaymentSettings = {
  upi_id: string | null;
  upi_name: string | null;
  qr_image_url: string | null;
  deposit_note: string | null;
  withdrawal_note: string | null;
};

type WalletRequest = {
  id: string;
  amount: number;
  currency: string;
  status: string;
  created_at: string;
  utr?: string;
  upi_id?: string;
  admin_note?: string | null;
};

export function WalletDialog({
  open,
  onOpenChange,
  initialTab = "deposit",
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initialTab?: "deposit" | "withdraw" | "history";
}) {
  const { user, profile } = useAuth();
  const [settings, setSettings] = useState<PaymentSettings | null>(null);
  const [tab, setTab] = useState<string>(initialTab);

  // Deposit state
  const [step, setStep] = useState<"amount" | "pay">("amount");
  const [amount, setAmount] = useState("");
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Withdraw state
  const [wAmount, setWAmount] = useState("");
  const [wUpi, setWUpi] = useState("");
  const [wName, setWName] = useState("");

  // History
  const [deposits, setDeposits] = useState<WalletRequest[]>([]);
  const [withdrawals, setWithdrawals] = useState<WalletRequest[]>([]);

  useEffect(() => {
    if (!open) return;
    setTab(initialTab);
    void supabase
      .from("admin_payment_settings")
      .select("upi_id, upi_name, qr_image_url, deposit_note, withdrawal_note")
      .eq("is_active", true)
      .maybeSingle()
      .then(({ data }) => setSettings(data as PaymentSettings | null));
  }, [open, initialTab]);

  useEffect(() => {
    if (!open || !user) return;
    const loadHistory = async () => {
      const [d, w] = await Promise.all([
        supabase.from("deposit_requests").select("id, amount, currency, status, created_at, utr").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20),
        supabase.from("withdrawal_requests").select("id, amount, currency, status, created_at, upi_id, admin_note").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20),
      ]);
      setDeposits((d.data ?? []) as WalletRequest[]);
      setWithdrawals((w.data ?? []) as WalletRequest[]);
    };
    void loadHistory();
    const ch = supabase
      .channel("wallet-" + user.id)
      .on("postgres_changes", { event: "*", schema: "public", table: "deposit_requests", filter: `user_id=eq.${user.id}` }, () => void loadHistory())
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawal_requests", filter: `user_id=eq.${user.id}` }, () => void loadHistory())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [open, user]);

  const resetDeposit = () => {
    setStep("amount");
    setAmount("");
    setUtr("");
    setScreenshot(null);
  };

  const submitDeposit = async () => {
    if (!user) return;
    const amt = Number(amount);
    if (!amt || amt <= 0) return toast.error("Enter a valid amount");
    if (utr.trim().length < 6) return toast.error("Enter UTR / Transaction ID");
    setSubmitting(true);
    try {
      let screenshotUrl: string | null = null;
      if (screenshot) {
        const ext = screenshot.name.split(".").pop() ?? "jpg";
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage.from("deposit-screenshots").upload(path, screenshot);
        if (upErr) {
          toast.error("Screenshot upload failed: " + upErr.message);
          setSubmitting(false);
          return;
        }
        const { data: pub } = supabase.storage.from("deposit-screenshots").getPublicUrl(path);
        screenshotUrl = pub.publicUrl;
      }
      const res = await createDepositRequest({
        amount: amt,
        currency: profile?.currency ?? "INR",
        utr: utr.trim(),
        screenshotUrl,
      });
      if (!res.ok) toast.error(res.error ?? "Failed");
      else {
        toast.success("Deposit request submitted! Awaiting admin approval.");
        resetDeposit();
        setTab("history");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const submitWithdrawal = async () => {
    const amt = Number(wAmount);
    if (!amt || amt <= 0) return toast.error("Enter a valid amount");
    if (wUpi.trim().length < 3) return toast.error("Enter UPI ID");
    setSubmitting(true);
    try {
      const res = await createWithdrawalRequest({
        amount: amt,
        currency: profile?.currency ?? "INR",
        upiId: wUpi.trim(),
        accountName: wName.trim() || null,
      });
      if (!res.ok) toast.error(res.error ?? "Failed");
      else {
        toast.success("Withdrawal request submitted!");
        setWAmount("");
        setWUpi("");
        setWName("");
        setTab("history");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const copyUpi = () => {
    if (!settings?.upi_id) return;
    navigator.clipboard.writeText(settings.upi_id);
    toast.success("UPI ID copied");
  };

  const currency = profile?.currency ?? "INR";
  const balance = profile ? (currency === "INR" ? Number(profile.balance_inr) : Number(profile.balance_usd)) : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0f1012] border-[#2c2d31] text-foreground max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Wallet</DialogTitle>
        </DialogHeader>

        <div className="bg-[#1b1c1f] rounded-lg p-3 mb-3">
          <div className="text-xs text-muted-foreground">Balance</div>
          <div className="text-2xl font-bold text-[#28a909]">
            {balance.toFixed(2)} <span className="text-sm text-muted-foreground">{currency}</span>
          </div>
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="grid grid-cols-3 bg-[#1b1c1f]">
            <TabsTrigger value="deposit">Deposit</TabsTrigger>
            <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="deposit" className="space-y-3 mt-3">
            {step === "amount" ? (
              <>
                <label className="text-xs text-muted-foreground">Amount ({currency})</label>
                <Input
                  type="number"
                  inputMode="decimal"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="bg-[#1b1c1f] border-[#2c2d31]"
                />
                <div className="flex gap-2">
                  {["100", "500", "1000", "5000"].map((q) => (
                    <button
                      key={q}
                      onClick={() => setAmount(q)}
                      className="flex-1 py-1.5 bg-[#2c2d31] rounded text-xs"
                    >
                      +{q}
                    </button>
                  ))}
                </div>
                <Button
                  onClick={() => {
                    if (!amount || Number(amount) <= 0) return toast.error("Enter amount");
                    setStep("pay");
                  }}
                  className="w-full bg-[#28a909] hover:bg-[#23990a]"
                >
                  Continue to Payment
                </Button>
              </>
            ) : (
              <>
                <div className="bg-[#1b1c1f] rounded-lg p-3 space-y-2">
                  <div className="text-xs text-muted-foreground">Pay this amount</div>
                  <div className="text-2xl font-bold">{Number(amount).toFixed(2)} {currency}</div>
                </div>

                {settings?.qr_image_url && (
                  <div className="flex justify-center bg-white rounded-lg p-3">
                    <img src={settings.qr_image_url} alt="UPI QR Code" className="w-48 h-48 object-contain" />
                  </div>
                )}

                <div className="bg-[#1b1c1f] rounded-lg p-3 space-y-2">
                  <div className="text-xs text-muted-foreground">UPI ID</div>
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-mono text-sm break-all">{settings?.upi_id ?? "Not set"}</div>
                    <button onClick={copyUpi} className="p-2 bg-[#2c2d31] rounded">
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                  {settings?.upi_name && (
                    <div className="text-xs text-muted-foreground">Name: {settings.upi_name}</div>
                  )}
                </div>

                {settings?.deposit_note && (
                  <div className="text-xs text-muted-foreground bg-[#1b1c1f] rounded-lg p-3">
                    {settings.deposit_note}
                  </div>
                )}

                <div className="space-y-2">
                  <label className="text-xs text-muted-foreground">UTR / Transaction ID</label>
                  <Input
                    placeholder="12-digit UTR number"
                    value={utr}
                    onChange={(e) => setUtr(e.target.value)}
                    className="bg-[#1b1c1f] border-[#2c2d31]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-muted-foreground">Payment Screenshot (optional)</label>
                  <label className="flex items-center justify-center gap-2 w-full py-3 bg-[#1b1c1f] border border-dashed border-[#2c2d31] rounded-lg cursor-pointer text-sm">
                    <Upload className="w-4 h-4" />
                    {screenshot ? screenshot.name.slice(0, 30) : "Upload screenshot"}
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => setScreenshot(e.target.files?.[0] ?? null)}
                    />
                  </label>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => setStep("amount")}
                    variant="outline"
                    className="flex-1"
                    disabled={submitting}
                  >
                    Back
                  </Button>
                  <Button
                    onClick={submitDeposit}
                    disabled={submitting || !utr}
                    className="flex-1 bg-[#28a909] hover:bg-[#23990a]"
                  >
                    {submitting ? "Submitting..." : "Submit Request"}
                  </Button>
                </div>
              </>
            )}
          </TabsContent>

          <TabsContent value="withdraw" className="space-y-3 mt-3">
            <label className="text-xs text-muted-foreground">Amount ({currency})</label>
            <Input
              type="number"
              placeholder="Amount to withdraw"
              value={wAmount}
              onChange={(e) => setWAmount(e.target.value)}
              className="bg-[#1b1c1f] border-[#2c2d31]"
            />
            <label className="text-xs text-muted-foreground">Your UPI ID</label>
            <Input
              placeholder="yourname@upi"
              value={wUpi}
              onChange={(e) => setWUpi(e.target.value)}
              className="bg-[#1b1c1f] border-[#2c2d31]"
            />
            <label className="text-xs text-muted-foreground">Account holder name (optional)</label>
            <Input
              placeholder="Full name"
              value={wName}
              onChange={(e) => setWName(e.target.value)}
              className="bg-[#1b1c1f] border-[#2c2d31]"
            />
            {settings?.withdrawal_note && (
              <div className="text-xs text-muted-foreground bg-[#1b1c1f] rounded-lg p-3">
                {settings.withdrawal_note}
              </div>
            )}
            <Button
              onClick={submitWithdrawal}
              disabled={submitting || !wAmount || !wUpi}
              className="w-full bg-[#28a909] hover:bg-[#23990a]"
            >
              {submitting ? "Submitting..." : "Request Withdrawal"}
            </Button>
          </TabsContent>

          <TabsContent value="history" className="space-y-3 mt-3">
            <div>
              <div className="text-xs text-muted-foreground mb-2">Deposits</div>
              {deposits.length === 0 ? (
                <div className="text-xs text-muted-foreground py-2">No deposits yet</div>
              ) : (
                <div className="space-y-1.5">
                  {deposits.map((r) => (
                    <div key={r.id} className="flex items-center justify-between bg-[#1b1c1f] rounded p-2 text-sm">
                      <div>
                        <div className="font-medium">+{Number(r.amount).toFixed(2)} {r.currency}</div>
                        <div className="text-[10px] text-muted-foreground">UTR: {r.utr}</div>
                      </div>
                      <StatusBadge status={r.status} />
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-2">Withdrawals</div>
              {withdrawals.length === 0 ? (
                <div className="text-xs text-muted-foreground py-2">No withdrawals yet</div>
              ) : (
                <div className="space-y-1.5">
                  {withdrawals.map((r) => (
                    <div key={r.id} className="flex items-center justify-between bg-[#1b1c1f] rounded p-2 text-sm">
                      <div>
                        <div className="font-medium">-{Number(r.amount).toFixed(2)} {r.currency}</div>
                        <div className="text-[10px] text-muted-foreground">{r.upi_id}</div>
                      </div>
                      <StatusBadge status={r.status} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function StatusBadge({ status }: { status: string }) {
  const cls =
    status === "approved"
      ? "bg-[#28a909]/20 text-[#28a909]"
      : status === "rejected"
        ? "bg-[#e50539]/20 text-[#e50539]"
        : "bg-[#a855f7]/20 text-[#a855f7]";
  return <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-semibold ${cls}`}>{status}</span>;
}