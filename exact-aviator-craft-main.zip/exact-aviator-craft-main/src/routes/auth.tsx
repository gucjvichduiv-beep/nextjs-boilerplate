import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  component: AuthPage,
});

function AuthPage() {
  const { user, loading, signUpEmail, signInEmail } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate({ to: "/" });
  }, [loading, user, navigate]);

  const submit = async () => {
    setBusy(true);
    try {
      const res =
        mode === "signup"
          ? await signUpEmail(email, password, username || "player")
          : await signInEmail(email, password);
      if (res.error) toast.error(res.error);
      else {
        toast.success(mode === "signup" ? "Account created!" : "Signed in!");
        navigate({ to: "/" });
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0e10] text-foreground flex flex-col items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <h1
            className="text-[#e50539] font-extrabold italic text-5xl tracking-tight"
            style={{ fontFamily: "'Pacifico', 'Brush Script MT', cursive" }}
          >
            Aviator
          </h1>
          <p className="text-muted-foreground text-sm mt-2">
            {mode === "signup" ? "Create your account to play" : "Sign in to continue"}
          </p>
        </div>

        <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-3">
          <div className="flex gap-2 mb-2">
            <button
              onClick={() => setMode("login")}
              className={`flex-1 py-2 rounded text-sm font-medium ${mode === "login" ? "bg-[#e50539] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
            >
              Log in
            </button>
            <button
              onClick={() => setMode("signup")}
              className={`flex-1 py-2 rounded text-sm font-medium ${mode === "signup" ? "bg-[#e50539] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
            >
              Sign up
            </button>
          </div>
          {mode === "signup" && (
            <Input
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="bg-[#0f1012] border-[#2c2d31]"
            />
          )}
          <Input
            placeholder="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="bg-[#0f1012] border-[#2c2d31]"
          />
          <Input
            placeholder="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="bg-[#0f1012] border-[#2c2d31]"
          />
          <Button
            onClick={submit}
            disabled={busy || !email || !password}
            className="w-full bg-[#28a909] hover:bg-[#23990a]"
          >
            {mode === "signup" ? "Create account" : "Log in"}
          </Button>
        </div>
      </div>
    </div>
  );
}