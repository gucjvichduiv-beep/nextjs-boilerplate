import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { reviewDepositRequest, reviewWithdrawalRequest, claimInitialAdmin } from "@/server/game";
import { toast } from "sonner";
import { LogOut, Upload, Trash2, Volume2, Shield, UserPlus, Users as UsersIcon, Plus, Minus, Gift, Copy } from "lucide-react";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
});

type DepositRow = {
  id: string;
  user_id: string;
  amount: number;
  currency: string;
  utr: string;
  screenshot_url: string | null;
  status: string;
  created_at: string;
  admin_note: string | null;
};

type WithdrawalRow = {
  id: string;
  user_id: string;
  amount: number;
  currency: string;
  upi_id: string;
  account_name: string | null;
  status: string;
  created_at: string;
  admin_note: string | null;
};

type SettingsRow = {
  id: string;
  upi_id: string | null;
  upi_name: string | null;
  qr_image_url: string | null;
  deposit_note: string | null;
  withdrawal_note: string | null;
};

type GameSettingsRow = {
  id: string;
  mode: string;
  fixed_crash: number | null;
  min_crash: number;
  max_crash: number;
  instant_crash_chance: number;
};

type SoundRow = {
  id: string;
  event_key: string;
  label: string;
  audio_url: string | null;
  volume: number;
  loop: boolean;
  is_enabled: boolean;
};

type PlaneSettingsRow = {
  id: string;
  body_color: string;
  accent_color: string;
  trail_color: string;
  style: string;
  scale: number;
  image_url: string | null;
};

function AdminPage() {
  const { user, loading, isAdmin, signInEmail, signOut, refreshRole } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [claimEmail, setClaimEmail] = useState("");

  const submitLogin = async () => {
    setBusy(true);
    try {
      const res = await signInEmail(email, password);
      if (res.error) toast.error(res.error);
      else {
        toast.success("Signed in");
        await refreshRole();
      }
    } finally {
      setBusy(false);
    }
  };

  const submitClaim = async () => {
    setBusy(true);
    try {
      const res = await claimInitialAdmin({ email: claimEmail.trim() });
      if (!res.ok) toast.error("Could not claim admin (already claimed or email mismatch)");
      else {
        toast.success("You are now admin!");
        await refreshRole();
      }
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen bg-[#0d0e10] flex items-center justify-center text-muted-foreground">Loading…</div>;
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0d0e10] flex items-center justify-center px-4">
        <div className="w-full max-w-sm bg-[#1b1c1f] rounded-lg p-5 space-y-3">
          <h1 className="text-xl font-bold text-center">Admin Login</h1>
          <Input placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-[#0f1012] border-[#2c2d31]" />
          <Input placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-[#0f1012] border-[#2c2d31]" />
          <Button onClick={submitLogin} disabled={busy || !email || !password} className="w-full bg-[#28a909] hover:bg-[#23990a]">
            {busy ? "..." : "Log in"}
          </Button>
          <Link to="/" className="block text-center text-xs text-muted-foreground hover:text-foreground">
            Back to game
          </Link>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#0d0e10] flex items-center justify-center px-4">
        <div className="w-full max-w-sm bg-[#1b1c1f] rounded-lg p-5 space-y-3 text-center">
          <h1 className="text-xl font-bold">Not an admin</h1>
          <p className="text-sm text-muted-foreground">
            Your account isn't an admin. If no admin exists yet, claim it now.
          </p>
          <Input placeholder="Your account email" value={claimEmail} onChange={(e) => setClaimEmail(e.target.value)} className="bg-[#0f1012] border-[#2c2d31]" />
          <Button onClick={submitClaim} disabled={busy || !claimEmail} className="w-full bg-[#e50539] hover:bg-[#c40432]">
            Claim initial admin
          </Button>
          <div className="flex gap-2 pt-2">
            <Button onClick={() => signOut().then(() => navigate({ to: "/auth" }))} variant="outline" className="flex-1">
              Sign out
            </Button>
            <Link to="/" className="flex-1">
              <Button variant="outline" className="w-full">Back</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return <AdminDashboard />;
}

function AdminDashboard() {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const [deposits, setDeposits] = useState<DepositRow[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRow[]>([]);
  const [settings, setSettings] = useState<SettingsRow | null>(null);
  const [gameSettings, setGameSettings] = useState<GameSettingsRow | null>(null);
  const [sounds, setSounds] = useState<SoundRow[]>([]);
  const [planeSettings, setPlaneSettings] = useState<PlaneSettingsRow | null>(null);
  const [reviewing, setReviewing] = useState<string | null>(null);
  const [adminNote, setAdminNote] = useState<Record<string, string>>({});

  const reload = async () => {
    const [d, w, s, g, snd, pl] = await Promise.all([
      supabase.from("deposit_requests").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("withdrawal_requests").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("admin_payment_settings").select("*").eq("is_active", true).maybeSingle(),
      supabase.from("game_settings").select("*").eq("is_active", true).maybeSingle(),
      supabase.from("game_sounds").select("*").order("event_key"),
      supabase.from("plane_settings").select("*").eq("is_active", true).maybeSingle(),
    ]);
    setDeposits((d.data ?? []) as DepositRow[]);
    setWithdrawals((w.data ?? []) as WithdrawalRow[]);
    setSettings((s.data as SettingsRow | null) ?? null);
    setGameSettings((g.data as GameSettingsRow | null) ?? null);
    setSounds((snd.data ?? []) as SoundRow[]);
    setPlaneSettings((pl.data as PlaneSettingsRow | null) ?? null);
  };

  useEffect(() => {
    void reload();
    const ch = supabase
      .channel("admin-feed")
      .on("postgres_changes", { event: "*", schema: "public", table: "deposit_requests" }, () => void reload())
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawal_requests" }, () => void reload())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  const review = async (kind: "deposit" | "withdraw", id: string, approve: boolean) => {
    setReviewing(id);
    try {
      const fn = kind === "deposit" ? reviewDepositRequest : reviewWithdrawalRequest;
      const res = await fn({ requestId: id, approve, adminNote: adminNote[id] || null });
      if (!res.ok) toast.error(res.error ?? "Review failed");
      else toast.success(approve ? "Approved" : "Rejected");
      await reload();
    } finally {
      setReviewing(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0e10] text-foreground">
      <header className="flex items-center justify-between px-4 py-3 bg-[#0f1012] border-b border-[#1f2024]">
        <div className="flex items-center gap-2">
          <span className="text-[#e50539] font-bold text-lg">Admin Panel</span>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/">
            <Button variant="outline" size="sm">Game</Button>
          </Link>
          <Button onClick={() => signOut().then(() => navigate({ to: "/auth" }))} variant="outline" size="sm">
            <LogOut className="w-3.5 h-3.5" />
          </Button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-4">
        <Tabs defaultValue="deposits">
          <TabsList className="grid grid-cols-4 sm:grid-cols-8 bg-[#1b1c1f] gap-1 h-auto">
            <TabsTrigger value="game">Game</TabsTrigger>
            <TabsTrigger value="deposits">
              Deposits ({deposits.filter((r) => r.status === "pending").length})
            </TabsTrigger>
            <TabsTrigger value="withdrawals">
              Withdraw ({withdrawals.filter((r) => r.status === "pending").length})
            </TabsTrigger>
            <TabsTrigger value="settings">Payment</TabsTrigger>
            <TabsTrigger value="sounds">Sounds</TabsTrigger>
            <TabsTrigger value="plane">Plane</TabsTrigger>
            <TabsTrigger value="promos">Promos</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="game" className="mt-3">
            {gameSettings && <GameControlForm settings={gameSettings} onSaved={reload} />}
          </TabsContent>

          <TabsContent value="deposits" className="mt-3 space-y-2">
            {deposits.length === 0 && <div className="text-center text-sm text-muted-foreground py-8">No deposit requests</div>}
            {deposits.map((r) => (
              <div key={r.id} className="bg-[#1b1c1f] rounded-lg p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-bold text-lg text-[#28a909]">+{Number(r.amount).toFixed(2)} {r.currency}</div>
                    <div className="text-xs text-muted-foreground">UTR: <span className="font-mono">{r.utr}</span></div>
                    <div className="text-[10px] text-muted-foreground">User: {r.user_id.slice(0, 8)} · {new Date(r.created_at).toLocaleString()}</div>
                  </div>
                  <StatusPill status={r.status} />
                </div>
                {r.screenshot_url && (
                  <a href={r.screenshot_url} target="_blank" rel="noreferrer" className="block">
                    <img src={r.screenshot_url} alt="Payment screenshot" className="w-full max-w-xs rounded border border-[#2c2d31]" />
                  </a>
                )}
                {r.status === "pending" && (
                  <>
                    <Input
                      placeholder="Admin note (optional)"
                      value={adminNote[r.id] ?? ""}
                      onChange={(e) => setAdminNote((p) => ({ ...p, [r.id]: e.target.value }))}
                      className="bg-[#0f1012] border-[#2c2d31] text-sm"
                    />
                    <div className="flex gap-2">
                      <Button onClick={() => review("deposit", r.id, true)} disabled={reviewing === r.id} className="flex-1 bg-[#28a909] hover:bg-[#23990a]">Approve</Button>
                      <Button onClick={() => review("deposit", r.id, false)} disabled={reviewing === r.id} variant="outline" className="flex-1">Reject</Button>
                    </div>
                  </>
                )}
                {r.admin_note && <div className="text-xs text-muted-foreground italic">Note: {r.admin_note}</div>}
              </div>
            ))}
          </TabsContent>

          <TabsContent value="withdrawals" className="mt-3 space-y-2">
            {withdrawals.length === 0 && <div className="text-center text-sm text-muted-foreground py-8">No withdrawal requests</div>}
            {withdrawals.map((r) => (
              <div key={r.id} className="bg-[#1b1c1f] rounded-lg p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-bold text-lg text-[#e50539]">-{Number(r.amount).toFixed(2)} {r.currency}</div>
                    <div className="text-xs">UPI: <span className="font-mono">{r.upi_id}</span></div>
                    {r.account_name && <div className="text-xs text-muted-foreground">Name: {r.account_name}</div>}
                    <div className="text-[10px] text-muted-foreground">User: {r.user_id.slice(0, 8)} · {new Date(r.created_at).toLocaleString()}</div>
                  </div>
                  <StatusPill status={r.status} />
                </div>
                {r.status === "pending" && (
                  <>
                    <Input
                      placeholder="Admin note (optional)"
                      value={adminNote[r.id] ?? ""}
                      onChange={(e) => setAdminNote((p) => ({ ...p, [r.id]: e.target.value }))}
                      className="bg-[#0f1012] border-[#2c2d31] text-sm"
                    />
                    <div className="flex gap-2">
                      <Button onClick={() => review("withdraw", r.id, true)} disabled={reviewing === r.id} className="flex-1 bg-[#28a909] hover:bg-[#23990a]">Approve & Paid</Button>
                      <Button onClick={() => review("withdraw", r.id, false)} disabled={reviewing === r.id} variant="outline" className="flex-1">Reject (refund)</Button>
                    </div>
                  </>
                )}
                {r.admin_note && <div className="text-xs text-muted-foreground italic">Note: {r.admin_note}</div>}
              </div>
            ))}
          </TabsContent>

          <TabsContent value="settings" className="mt-3">
            {settings && <SettingsForm settings={settings} onSaved={reload} />}
          </TabsContent>

          <TabsContent value="sounds" className="mt-3 space-y-2">
            <SoundsManager sounds={sounds} onChanged={reload} />
          </TabsContent>

          <TabsContent value="plane" className="mt-3">
            {planeSettings && <PlaneSettingsForm settings={planeSettings} onSaved={reload} />}
          </TabsContent>

          <TabsContent value="users" className="mt-3">
            <UsersManager />
          </TabsContent>

          <TabsContent value="promos" className="mt-3">
            <PromoCodesManager />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function GameControlForm({ settings, onSaved }: { settings: GameSettingsRow; onSaved: () => void }) {
  const [mode, setMode] = useState<string>(settings.mode);
  const [fixedCrash, setFixedCrash] = useState<string>(settings.fixed_crash != null ? String(settings.fixed_crash) : "");
  const [minCrash, setMinCrash] = useState<string>(String(settings.min_crash));
  const [maxCrash, setMaxCrash] = useState<string>(String(settings.max_crash));
  const [instantChance, setInstantChance] = useState<string>(String(Math.round(Number(settings.instant_crash_chance) * 100)));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setMode(settings.mode);
    setFixedCrash(settings.fixed_crash != null ? String(settings.fixed_crash) : "");
    setMinCrash(String(settings.min_crash));
    setMaxCrash(String(settings.max_crash));
    setInstantChance(String(Math.round(Number(settings.instant_crash_chance) * 100)));
  }, [settings]);

  const save = async () => {
    setSaving(true);
    try {
      const min = Number(minCrash);
      const max = Number(maxCrash);
      const chance = Math.min(100, Math.max(0, Number(instantChance) || 0)) / 100;
      if (!min || !max || min < 1 || max < min) {
        toast.error("Min/max must be ≥ 1 and max ≥ min");
        setSaving(false);
        return;
      }
      const fixed = mode === "fixed" ? Number(fixedCrash) : null;
      if (mode === "fixed" && (!fixed || fixed < 1)) {
        toast.error("Enter a valid fixed crash value (≥ 1.00)");
        setSaving(false);
        return;
      }
      const { error } = await supabase
        .from("game_settings")
        .update({
          mode,
          fixed_crash: fixed,
          min_crash: min,
          max_crash: max,
          instant_crash_chance: chance,
          updated_at: new Date().toISOString(),
        })
        .eq("id", settings.id);
      if (error) toast.error(error.message);
      else {
        toast.success(mode === "fixed" ? "Next round will crash at " + fixed + "x" : "Random range saved");
        onSaved();
      }
    } finally {
      setSaving(false);
    }
  };

  const quickFix = async (val: number) => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("game_settings")
        .update({
          mode: "fixed",
          fixed_crash: val,
          updated_at: new Date().toISOString(),
        })
        .eq("id", settings.id);
      if (error) toast.error(error.message);
      else {
        toast.success("Next round will crash at " + val + "x");
        onSaved();
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-3">
        <div>
          <div className="text-sm font-semibold mb-2">Mode</div>
          <div className="flex gap-2">
            <button
              onClick={() => setMode("random")}
              className={`flex-1 py-2 rounded text-sm font-medium ${mode === "random" ? "bg-[#28a909] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
            >
              Random (auto)
            </button>
            <button
              onClick={() => setMode("fixed")}
              className={`flex-1 py-2 rounded text-sm font-medium ${mode === "fixed" ? "bg-[#e50539] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
            >
              Fixed (next round)
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            <strong>Random</strong>: rounds crash randomly between min & max.{" "}
            <strong>Fixed</strong>: the very next round crashes exactly at your value, then auto-switches back to Random.
          </p>
        </div>

        {mode === "fixed" && (
          <div className="bg-[#0f1012] rounded p-3 space-y-2">
            <label className="text-xs text-muted-foreground">Next round crashes at (X)</label>
            <Input
              type="number"
              step="0.01"
              min="1"
              placeholder="e.g. 2.50"
              value={fixedCrash}
              onChange={(e) => setFixedCrash(e.target.value)}
              className="bg-[#1b1c1f] border-[#2c2d31] text-lg font-bold"
            />
            <div className="flex flex-wrap gap-1.5">
              {[1.00, 1.20, 1.50, 2.00, 3.00, 5.00, 10.00, 50.00].map((v) => (
                <button
                  key={v}
                  onClick={() => quickFix(v)}
                  disabled={saving}
                  className="px-2 py-1 bg-[#2c2d31] hover:bg-[#3c3d41] rounded text-xs"
                >
                  {v.toFixed(2)}x
                </button>
              ))}
            </div>
            <p className="text-[10px] text-muted-foreground">Tip: 1.00x = instant crash. Quick buttons apply immediately.</p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-muted-foreground">Min crash (random)</label>
            <Input
              type="number"
              step="0.01"
              min="1"
              value={minCrash}
              onChange={(e) => setMinCrash(e.target.value)}
              className="bg-[#0f1012] border-[#2c2d31]"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Max crash (random)</label>
            <Input
              type="number"
              step="0.01"
              min="1"
              value={maxCrash}
              onChange={(e) => setMaxCrash(e.target.value)}
              className="bg-[#0f1012] border-[#2c2d31]"
            />
          </div>
        </div>

        <div>
          <label className="text-xs text-muted-foreground">Instant-crash chance (%)</label>
          <Input
            type="number"
            min="0"
            max="100"
            value={instantChance}
            onChange={(e) => setInstantChance(e.target.value)}
            className="bg-[#0f1012] border-[#2c2d31]"
          />
          <p className="text-[10px] text-muted-foreground mt-1">
            % of random rounds that crash instantly at 1.00x (everyone loses).
          </p>
        </div>

        <Button onClick={save} disabled={saving} className="w-full bg-[#28a909] hover:bg-[#23990a]">
          {saving ? "Saving..." : "Save Settings"}
        </Button>
      </div>

      <div className="bg-[#1b1c1f] rounded-lg p-3 text-xs text-muted-foreground space-y-1">
        <div className="font-semibold text-foreground">Current state</div>
        <div>Mode: <span className="text-foreground font-mono">{settings.mode}</span></div>
        {settings.fixed_crash != null && (
          <div>Next round will crash at: <span className="text-[#e50539] font-bold">{Number(settings.fixed_crash).toFixed(2)}x</span></div>
        )}
        <div>Random range: <span className="text-foreground font-mono">{Number(settings.min_crash).toFixed(2)}x — {Number(settings.max_crash).toFixed(2)}x</span></div>
        <div>Instant-crash chance: <span className="text-foreground font-mono">{Math.round(Number(settings.instant_crash_chance) * 100)}%</span></div>
      </div>
    </div>
  );
}

function SettingsForm({ settings, onSaved }: { settings: SettingsRow; onSaved: () => void }) {
  const [upiId, setUpiId] = useState(settings.upi_id ?? "");
  const [upiName, setUpiName] = useState(settings.upi_name ?? "");
  const [depositNote, setDepositNote] = useState(settings.deposit_note ?? "");
  const [withdrawalNote, setWithdrawalNote] = useState(settings.withdrawal_note ?? "");
  const [qrUrl, setQrUrl] = useState(settings.qr_image_url ?? "");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const uploadQr = async (file: File) => {
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() ?? "png";
      const path = `qr-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("payment-assets").upload(path, file, { upsert: true });
      if (error) {
        toast.error("Upload failed: " + error.message);
        return;
      }
      const { data } = supabase.storage.from("payment-assets").getPublicUrl(path);
      setQrUrl(data.publicUrl);
      toast.success("QR uploaded");
    } finally {
      setUploading(false);
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("admin_payment_settings")
        .update({
          upi_id: upiId,
          upi_name: upiName,
          deposit_note: depositNote,
          withdrawal_note: withdrawalNote,
          qr_image_url: qrUrl || null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", settings.id);
      if (error) toast.error(error.message);
      else {
        toast.success("Settings saved");
        onSaved();
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-3">
      <div>
        <label className="text-xs text-muted-foreground">UPI ID</label>
        <Input value={upiId} onChange={(e) => setUpiId(e.target.value)} className="bg-[#0f1012] border-[#2c2d31]" />
      </div>
      <div>
        <label className="text-xs text-muted-foreground">UPI Name</label>
        <Input value={upiName} onChange={(e) => setUpiName(e.target.value)} className="bg-[#0f1012] border-[#2c2d31]" />
      </div>
      <div>
        <label className="text-xs text-muted-foreground">QR Image</label>
        <div className="flex items-center gap-3 mt-1">
          {qrUrl && <img src={qrUrl} alt="QR" className="w-20 h-20 object-contain bg-white rounded" />}
          <label className="flex-1 flex items-center justify-center gap-2 py-3 bg-[#0f1012] border border-dashed border-[#2c2d31] rounded cursor-pointer text-sm">
            <Upload className="w-4 h-4" />
            {uploading ? "Uploading..." : "Upload QR"}
            <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && uploadQr(e.target.files[0])} />
          </label>
        </div>
      </div>
      <div>
        <label className="text-xs text-muted-foreground">Deposit instructions</label>
        <Textarea value={depositNote} onChange={(e) => setDepositNote(e.target.value)} className="bg-[#0f1012] border-[#2c2d31]" />
      </div>
      <div>
        <label className="text-xs text-muted-foreground">Withdrawal instructions</label>
        <Textarea value={withdrawalNote} onChange={(e) => setWithdrawalNote(e.target.value)} className="bg-[#0f1012] border-[#2c2d31]" />
      </div>
      <Button onClick={save} disabled={saving} className="w-full bg-[#28a909] hover:bg-[#23990a]">
        {saving ? "Saving..." : "Save Settings"}
      </Button>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const cls =
    status === "approved"
      ? "bg-[#28a909]/20 text-[#28a909]"
      : status === "rejected"
        ? "bg-[#e50539]/20 text-[#e50539]"
        : "bg-[#a855f7]/20 text-[#a855f7]";
  return <span className={`text-[10px] px-2 py-1 rounded uppercase font-semibold ${cls}`}>{status}</span>;
}

function SoundsManager({ sounds, onChanged }: { sounds: SoundRow[]; onChanged: () => void }) {
  const [uploadingId, setUploadingId] = useState<string | null>(null);

  const upload = async (row: SoundRow, file: File) => {
    setUploadingId(row.id);
    try {
      const ext = file.name.split(".").pop() ?? "mp3";
      const path = `${row.event_key}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("game-sounds").upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) {
        toast.error("Upload failed: " + upErr.message);
        return;
      }
      const { data } = supabase.storage.from("game-sounds").getPublicUrl(path);
      const { error } = await supabase.from("game_sounds").update({ audio_url: data.publicUrl }).eq("id", row.id);
      if (error) toast.error(error.message);
      else {
        toast.success(`${row.label} uploaded`);
        onChanged();
      }
    } finally {
      setUploadingId(null);
    }
  };

  const updateRow = async (id: string, patch: Partial<SoundRow>) => {
    const { error } = await supabase.from("game_sounds").update(patch).eq("id", id);
    if (error) toast.error(error.message);
    else onChanged();
  };

  const clearClip = async (row: SoundRow) => {
    await updateRow(row.id, { audio_url: null });
    toast.success("Cleared (will use default synth)");
  };

  const preview = (url: string | null, volume: number) => {
    if (!url) {
      toast.info("No clip uploaded — default synth will play in game");
      return;
    }
    const a = new Audio(url);
    a.volume = volume;
    void a.play().catch(() => toast.error("Playback blocked"));
  };

  return (
    <div className="space-y-2">
      <div className="bg-[#1b1c1f] rounded-lg p-3 text-xs text-muted-foreground">
        Upload mp3/wav clips for each game event. If no clip is uploaded, the built-in synth sound is used as a fallback.
      </div>
      {sounds.map((s) => (
        <div key={s.id} className="bg-[#1b1c1f] rounded-lg p-3 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="font-semibold text-sm">{s.label}</div>
              <div className="text-[10px] text-muted-foreground font-mono">{s.event_key}{s.loop ? " · loop" : ""}</div>
            </div>
            <label className="flex items-center gap-1.5 text-xs cursor-pointer">
              <input
                type="checkbox"
                checked={s.is_enabled}
                onChange={(e) => updateRow(s.id, { is_enabled: e.target.checked })}
              />
              Enabled
            </label>
          </div>

          {s.audio_url && (
            <audio controls src={s.audio_url} className="w-full h-8" />
          )}

          <div className="flex flex-wrap items-center gap-2">
            <label className="flex-1 min-w-[140px] flex items-center justify-center gap-1.5 py-2 bg-[#0f1012] border border-dashed border-[#2c2d31] rounded cursor-pointer text-xs">
              <Upload className="w-3.5 h-3.5" />
              {uploadingId === s.id ? "Uploading..." : s.audio_url ? "Replace clip" : "Upload clip"}
              <input
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && upload(s, e.target.files[0])}
              />
            </label>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => preview(s.audio_url, Number(s.volume))}
              className="h-9"
            >
              <Volume2 className="w-3.5 h-3.5" />
            </Button>
            {s.audio_url && (
              <Button type="button" size="sm" variant="outline" onClick={() => clearClip(s)} className="h-9">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <label className="text-[10px] text-muted-foreground w-14">Volume</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              defaultValue={s.volume}
              onMouseUp={(e) => updateRow(s.id, { volume: Number((e.target as HTMLInputElement).value) })}
              onTouchEnd={(e) => updateRow(s.id, { volume: Number((e.target as HTMLInputElement).value) })}
              className="flex-1"
            />
            <span className="text-[10px] font-mono w-8 text-right">{Math.round(Number(s.volume) * 100)}%</span>
          </div>
        </div>
      ))}
    </div>
  );
}
function PlaneSettingsForm({ settings, onSaved }: { settings: PlaneSettingsRow; onSaved: () => void }) {
  const [bodyColor, setBodyColor] = useState(settings.body_color);
  const [accentColor, setAccentColor] = useState(settings.accent_color);
  const [trailColor, setTrailColor] = useState(settings.trail_color);
  const [style, setStyle] = useState(settings.style);
  const [scale, setScale] = useState<number>(Number(settings.scale ?? 1));
  const [saving, setSaving] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(settings.image_url);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    setBodyColor(settings.body_color);
    setAccentColor(settings.accent_color);
    setTrailColor(settings.trail_color);
    setStyle(settings.style);
    setScale(Number(settings.scale ?? 1));
    setImageUrl(settings.image_url);
  }, [settings]);

  const save = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("plane_settings")
        .update({
          body_color: bodyColor,
          accent_color: accentColor,
          trail_color: trailColor,
          style,
          scale,
          image_url: imageUrl,
        })
        .eq("id", settings.id);
      if (error) toast.error(error.message);
      else {
        toast.success("Plane updated — live for all players");
        onSaved();
      }
    } finally {
      setSaving(false);
    }
  };

  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Image must be under 2MB");
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const path = `plane-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("plane-images").upload(path, file, {
        upsert: true,
        contentType: file.type,
      });
      if (upErr) {
        toast.error(upErr.message);
        return;
      }
      const { data } = supabase.storage.from("plane-images").getPublicUrl(path);
      setImageUrl(data.publicUrl);
      toast.success("Image uploaded — click Save to apply");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const styles: { key: string; label: string }[] = [
    { key: "classic", label: "Classic Plane" },
    { key: "jet", label: "✈️ Jet" },
    { key: "rocket", label: "🚀 Rocket" },
    { key: "helicopter", label: "🚁 Heli" },
    { key: "ufo", label: "🛸 UFO" },
    { key: "car", label: "🏎️ Car" },
  ];

  return (
    <div className="space-y-3">
      <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-3">
        <div>
          <div className="text-sm font-semibold mb-2">Custom Plane Image</div>
          <div className="flex items-center gap-2">
            {imageUrl ? (
              <img src={imageUrl} alt="plane" className="w-16 h-16 object-contain bg-[#0f1012] rounded border border-[#2c2d31]" />
            ) : (
              <div className="w-16 h-16 bg-[#0f1012] rounded border border-[#2c2d31] flex items-center justify-center text-[10px] text-muted-foreground">None</div>
            )}
            <label className="flex-1">
              <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={onUpload} className="hidden" />
              <div className="cursor-pointer text-center py-2 px-3 rounded bg-[#2c2d31] text-xs font-medium hover:bg-[#3a3b40]">
                {uploading ? "Uploading…" : "Upload Image"}
              </div>
            </label>
            {imageUrl && (
              <Button onClick={() => setImageUrl(null)} variant="outline" size="sm" className="text-xs">
                Clear
              </Button>
            )}
          </div>
          <p className="text-[10px] text-muted-foreground mt-1">Uploaded image overrides the style below. Max 2MB.</p>
        </div>

        <div>
          <div className="text-sm font-semibold mb-2">Style</div>
          <div className="grid grid-cols-3 gap-2">
            {styles.map((s) => (
              <button
                key={s.key}
                onClick={() => setStyle(s.key)}
                className={`py-2 rounded text-xs font-medium ${style === s.key ? "bg-[#28a909] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div>
            <label className="text-xs text-muted-foreground">Body</label>
            <input
              type="color"
              value={bodyColor}
              onChange={(e) => setBodyColor(e.target.value)}
              className="w-full h-10 rounded bg-[#0f1012] border border-[#2c2d31] cursor-pointer"
            />
            <div className="text-[10px] font-mono text-center mt-1">{bodyColor}</div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Accent</label>
            <input
              type="color"
              value={accentColor}
              onChange={(e) => setAccentColor(e.target.value)}
              className="w-full h-10 rounded bg-[#0f1012] border border-[#2c2d31] cursor-pointer"
            />
            <div className="text-[10px] font-mono text-center mt-1">{accentColor}</div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Trail</label>
            <input
              type="color"
              value={trailColor}
              onChange={(e) => setTrailColor(e.target.value)}
              className="w-full h-10 rounded bg-[#0f1012] border border-[#2c2d31] cursor-pointer"
            />
            <div className="text-[10px] font-mono text-center mt-1">{trailColor}</div>
          </div>
        </div>

        <div>
          <label className="text-xs text-muted-foreground">Size: {scale.toFixed(2)}x</label>
          <input
            type="range"
            min={0.5}
            max={2}
            step={0.05}
            value={scale}
            onChange={(e) => setScale(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div className="bg-[#0f1012] rounded p-4 flex items-center justify-center">
          <PlanePreview body={bodyColor} accent={accentColor} trail={trailColor} style={style} scale={scale} />
        </div>

        <Button onClick={save} disabled={saving} className="w-full bg-[#28a909] hover:bg-[#23990a]">
          {saving ? "Saving..." : "Save Plane Settings"}
        </Button>
      </div>
    </div>
  );
}

function PromoCodesManager() {
  type PromoRow = {
    id: string;
    code: string;
    amount: number;
    currency: string;
    max_total_uses: number | null;
    max_per_user: number;
    expires_at: string | null;
    is_active: boolean;
    note: string | null;
    created_at: string;
  };
  const [codes, setCodes] = useState<PromoRow[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState(false);

  // form state
  const [code, setCode] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState<"INR" | "USD">("INR");
  const [maxTotal, setMaxTotal] = useState("");
  const [maxPerUser, setMaxPerUser] = useState("1");
  const [expiryHours, setExpiryHours] = useState("");
  const [note, setNote] = useState("");

  const load = async () => {
    const { data } = await supabase
      .from("promo_codes")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);
    const rows = (data ?? []) as PromoRow[];
    setCodes(rows);
    if (rows.length) {
      const ids = rows.map((r) => r.id);
      const { data: reds } = await supabase
        .from("promo_code_redemptions")
        .select("promo_code_id")
        .in("promo_code_id", ids);
      const map: Record<string, number> = {};
      (reds ?? []).forEach((r: { promo_code_id: string }) => {
        map[r.promo_code_id] = (map[r.promo_code_id] ?? 0) + 1;
      });
      setCounts(map);
    } else {
      setCounts({});
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const generateCode = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let s = "";
    for (let i = 0; i < 8; i++) s += chars[Math.floor(Math.random() * chars.length)];
    setCode(s);
  };

  const create = async () => {
    const amt = Number(amount);
    if (!code.trim() || !amt || amt <= 0) {
      toast.error("Enter code and a valid amount");
      return;
    }
    setBusy(true);
    try {
      const expiresAt = expiryHours.trim()
        ? new Date(Date.now() + Number(expiryHours) * 3600 * 1000).toISOString()
        : null;
      const { error } = await supabase.from("promo_codes").insert({
        code: code.trim().toUpperCase(),
        amount: amt,
        currency,
        max_total_uses: maxTotal.trim() ? Number(maxTotal) : null,
        max_per_user: Number(maxPerUser) || 1,
        expires_at: expiresAt,
        note: note.trim() || null,
      });
      if (error) {
        toast.error(error.message);
        return;
      }
      toast.success("Promo code created");
      setCode(""); setAmount(""); setMaxTotal(""); setMaxPerUser("1"); setExpiryHours(""); setNote("");
      await load();
    } finally {
      setBusy(false);
    }
  };

  const toggleActive = async (id: string, active: boolean) => {
    const { error } = await supabase.from("promo_codes").update({ is_active: !active }).eq("id", id);
    if (error) toast.error(error.message);
    else await load();
  };

  const remove = async (id: string) => {
    if (!window.confirm("Delete this promo code? All redemption history will be removed.")) return;
    const { error } = await supabase.from("promo_codes").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Deleted");
      await load();
    }
  };

  const copy = (text: string) => {
    void navigator.clipboard.writeText(text);
    toast.success("Copied");
  };

  return (
    <div className="space-y-3">
      <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Gift className="w-4 h-4 text-[#e50539]" />
          <h3 className="text-sm font-semibold">Create Promo Code</h3>
        </div>

        <div>
          <label className="text-xs text-muted-foreground">Code</label>
          <div className="flex gap-2">
            <Input
              placeholder="WELCOME50"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              className="bg-[#0f1012] border-[#2c2d31] uppercase font-mono"
              maxLength={50}
            />
            <Button onClick={generateCode} variant="outline" size="sm">Auto</Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs text-muted-foreground">Amount</label>
            <Input
              type="number"
              step="0.01"
              placeholder="50"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-[#0f1012] border-[#2c2d31]"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Currency</label>
            <div className="flex gap-1 mt-1">
              {(["INR", "USD"] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => setCurrency(c)}
                  className={`flex-1 py-1.5 rounded text-xs font-medium ${currency === c ? "bg-[#28a909] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs text-muted-foreground">Total uses (blank = ∞)</label>
            <Input
              type="number"
              placeholder="100"
              value={maxTotal}
              onChange={(e) => setMaxTotal(e.target.value)}
              className="bg-[#0f1012] border-[#2c2d31]"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Per user limit</label>
            <Input
              type="number"
              placeholder="1"
              value={maxPerUser}
              onChange={(e) => setMaxPerUser(e.target.value)}
              className="bg-[#0f1012] border-[#2c2d31]"
            />
          </div>
        </div>

        <div>
          <label className="text-xs text-muted-foreground">Expires in (hours, blank = never)</label>
          <Input
            type="number"
            placeholder="24"
            value={expiryHours}
            onChange={(e) => setExpiryHours(e.target.value)}
            className="bg-[#0f1012] border-[#2c2d31]"
          />
        </div>

        <div>
          <label className="text-xs text-muted-foreground">Note (optional)</label>
          <Input
            placeholder="Welcome bonus"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="bg-[#0f1012] border-[#2c2d31]"
            maxLength={200}
          />
        </div>

        <Button onClick={create} disabled={busy} className="w-full bg-[#28a909] hover:bg-[#23990a]">
          {busy ? "Creating..." : "Create Promo Code"}
        </Button>
      </div>

      <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-2">
        <h3 className="text-sm font-semibold">All Promo Codes ({codes.length})</h3>
        {codes.length === 0 && <p className="text-xs text-muted-foreground py-4 text-center">No promo codes yet.</p>}
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {codes.map((c) => {
            const used = counts[c.id] ?? 0;
            const expired = c.expires_at ? new Date(c.expires_at) < new Date() : false;
            return (
              <div key={c.id} className="bg-[#0f1012] rounded p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <button
                      onClick={() => copy(c.code)}
                      className="font-mono font-bold text-base text-[#28a909] flex items-center gap-1 hover:opacity-80"
                    >
                      {c.code}
                      <Copy className="w-3 h-3 opacity-50" />
                    </button>
                    <div className="text-xs text-muted-foreground">
                      +{Number(c.amount).toFixed(2)} {c.currency} · {used}/{c.max_total_uses ?? "∞"} used · {c.max_per_user}/user
                    </div>
                    {c.expires_at && (
                      <div className={`text-[10px] ${expired ? "text-[#e50539]" : "text-muted-foreground"}`}>
                        {expired ? "Expired" : "Expires"} {new Date(c.expires_at).toLocaleString()}
                      </div>
                    )}
                    {c.note && <div className="text-[10px] text-muted-foreground italic">{c.note}</div>}
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${c.is_active && !expired ? "bg-[#28a909]/20 text-[#28a909]" : "bg-[#2c2d31] text-muted-foreground"}`}>
                      {c.is_active && !expired ? "Active" : "Inactive"}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => toggleActive(c.id, c.is_active)}
                    size="sm"
                    variant="outline"
                    className="flex-1 h-7 text-xs"
                  >
                    {c.is_active ? "Disable" : "Enable"}
                  </Button>
                  <Button
                    onClick={() => remove(c.id)}
                    size="sm"
                    variant="outline"
                    className="h-7 text-xs text-[#e50539] hover:text-[#e50539]"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function PlanePreview({ body, accent, trail, style, scale }: { body: string; accent: string; trail: string; style: string; scale: number }) {
  const emojiMap: Record<string, string> = {
    rocket: "🚀", jet: "✈️", helicopter: "🚁", ufo: "🛸", car: "🏎️",
  };
  if (emojiMap[style]) {
    return <div style={{ fontSize: 80 * scale, filter: `drop-shadow(0 0 12px ${trail})` }}>{emojiMap[style]}</div>;
  }
  return (
    <svg width={120 * scale} height={90 * scale} viewBox="-60 -45 120 90" style={{ filter: `drop-shadow(0 0 12px ${trail})` }}>
      <path d="M-40,0 L35,-10 Q50,0 35,10 Z" fill={body} />
      <path d="M-5,-8 L-25,-28 L-15,-28 L10,-8 Z" fill={body} />
      <path d="M-5,8 L-25,28 L-15,28 L10,8 Z" fill={body} />
      <path d="M-40,-2 L-50,-16 L-42,-16 L-32,-2 Z" fill={body} />
      <ellipse cx="20" cy="-2" rx="8" ry="4" fill={accent} />
      <rect x="-30" y="-2" width="55" height="2" fill={accent} />
    </svg>
  );
}

function UsersManager() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  type UserRow = {
    user_id: string;
    email: string | null;
    username: string | null;
    is_guest: boolean;
    balance_inr: number;
    balance_usd: number;
    currency: string;
    created_at: string;
    is_admin: boolean;
  };
  const [users, setUsers] = useState<UserRow[]>([]);
  const [search, setSearch] = useState("");
  const [adjustOpen, setAdjustOpen] = useState<string | null>(null);
  const [adjustAmount, setAdjustAmount] = useState("");
  const [adjustCurrency, setAdjustCurrency] = useState<"INR" | "USD">("INR");

  const loadUsers = async () => {
    const { data, error } = await supabase.rpc("admin_list_users");
    if (error) {
      toast.error(error.message);
      return;
    }
    setUsers((data ?? []) as UserRow[]);
  };

  useEffect(() => {
    void loadUsers();
  }, []);

  const promote = async () => {
    if (!email.trim()) return;
    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("promote_user_to_admin", { _email: email.trim() });
      if (error) toast.error(error.message);
      else if (!data) toast.error("No user found with that email");
      else {
        toast.success("User promoted to admin");
        setEmail("");
        await loadUsers();
      }
    } finally {
      setBusy(false);
    }
  };

  const revoke = async () => {
    const input = window.prompt("Enter the email of the admin to revoke:");
    if (!input) return;
    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("revoke_admin", { _email: input.trim() });
      if (error) toast.error(error.message);
      else if (!data) toast.error("No admin found with that email");
      else {
        toast.success("Admin revoked");
        await loadUsers();
      }
    } finally {
      setBusy(false);
    }
  };

  const applyAdjust = async (userId: string, sign: 1 | -1) => {
    const amt = Number(adjustAmount);
    if (!amt || amt <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    setBusy(true);
    try {
      const { error } = await supabase.rpc("admin_adjust_balance", {
        _user_id: userId,
        _currency: adjustCurrency,
        _delta: sign * amt,
      });
      if (error) {
        toast.error(error.message);
        return;
      }
      toast.success(`${sign > 0 ? "Credited" : "Debited"} ${amt} ${adjustCurrency}`);
      setAdjustAmount("");
      setAdjustOpen(null);
      await loadUsers();
    } finally {
      setBusy(false);
    }
  };

  const filtered = users.filter((u) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (u.email ?? "").toLowerCase().includes(q) ||
      (u.username ?? "").toLowerCase().includes(q) ||
      u.user_id.toLowerCase().includes(q)
    );
  });
  const adminCount = users.filter((u) => u.is_admin).length;

  return (
    <div className="space-y-3">
      <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2">
          <UserPlus className="w-4 h-4 text-[#28a909]" />
          <h3 className="text-sm font-semibold">Promote user to admin</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Enter the email of an existing registered user. They will gain access to this admin panel.
        </p>
        <div className="flex gap-2">
          <Input
            type="email"
            placeholder="user@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="bg-[#0f1012] border-[#2c2d31]"
          />
          <Button onClick={promote} disabled={busy || !email.trim()} className="bg-[#28a909] hover:bg-[#23990a]">
            Promote
          </Button>
        </div>
        <Button onClick={revoke} disabled={busy} variant="outline" size="sm" className="w-full">
          <Shield className="w-3.5 h-3.5 mr-1" />
          Revoke an admin (by email)
        </Button>
      </div>

      <div className="bg-[#1b1c1f] rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UsersIcon className="w-4 h-4 text-[#28a909]" />
            <h3 className="text-sm font-semibold">
              All users ({users.length}) · Admins {adminCount}
            </h3>
          </div>
          <Button onClick={loadUsers} variant="outline" size="sm">Refresh</Button>
        </div>
        <Input
          placeholder="Search by email, username or ID…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="bg-[#0f1012] border-[#2c2d31] text-sm"
        />
        {filtered.length === 0 && (
          <p className="text-xs text-muted-foreground py-4 text-center">No users match.</p>
        )}
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {filtered.map((u) => (
            <div key={u.user_id} className="bg-[#0f1012] rounded p-3 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-sm truncate">{u.username ?? "—"}</span>
                    {u.is_admin && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#e50539]/20 text-[#e50539] font-bold uppercase">Admin</span>
                    )}
                    {u.is_guest && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#2c2d31] text-muted-foreground font-bold uppercase">Guest</span>
                    )}
                  </div>
                  <div className="text-[11px] text-muted-foreground truncate">{u.email ?? "(no email)"}</div>
                  <div className="text-[10px] font-mono text-muted-foreground">{u.user_id.slice(0, 12)}…</div>
                </div>
                <div className="text-right text-xs">
                  <div className="text-[#28a909] font-bold">₹{Number(u.balance_inr).toFixed(2)}</div>
                  <div className="text-muted-foreground">${Number(u.balance_usd).toFixed(2)}</div>
                </div>
              </div>
              {adjustOpen === u.user_id ? (
                <div className="space-y-2 pt-2 border-t border-[#2c2d31]">
                  <div className="flex gap-2">
                    <button
                      onClick={() => setAdjustCurrency("INR")}
                      className={`flex-1 py-1.5 rounded text-xs font-medium ${adjustCurrency === "INR" ? "bg-[#28a909] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
                    >
                      INR
                    </button>
                    <button
                      onClick={() => setAdjustCurrency("USD")}
                      className={`flex-1 py-1.5 rounded text-xs font-medium ${adjustCurrency === "USD" ? "bg-[#28a909] text-white" : "bg-[#2c2d31] text-muted-foreground"}`}
                    >
                      USD
                    </button>
                  </div>
                  <Input
                    type="number"
                    placeholder="Amount"
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(e.target.value)}
                    className="bg-[#1b1c1f] border-[#2c2d31] text-sm h-8"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={() => applyAdjust(u.user_id, 1)}
                      disabled={busy || !adjustAmount}
                      size="sm"
                      className="flex-1 bg-[#28a909] hover:bg-[#23990a] h-7 text-xs"
                    >
                      <Plus className="w-3 h-3 mr-1" /> Credit
                    </Button>
                    <Button
                      onClick={() => applyAdjust(u.user_id, -1)}
                      disabled={busy || !adjustAmount}
                      size="sm"
                      variant="outline"
                      className="flex-1 h-7 text-xs"
                    >
                      <Minus className="w-3 h-3 mr-1" /> Debit
                    </Button>
                    <Button
                      onClick={() => { setAdjustOpen(null); setAdjustAmount(""); }}
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs"
                    >
                      ✕
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  onClick={() => { setAdjustOpen(u.user_id); setAdjustAmount(""); }}
                  size="sm"
                  variant="outline"
                  className="w-full h-7 text-xs"
                >
                  Adjust balance
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
