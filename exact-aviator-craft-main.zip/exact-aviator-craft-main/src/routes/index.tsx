import { createFileRoute } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Header } from "@/components/aviator/Header";
import { MultiplierStrip } from "@/components/aviator/MultiplierStrip";
import { PlaneCanvas } from "@/components/aviator/PlaneCanvas";
import { BetPanel } from "@/components/aviator/BetPanel";
import { BetsList } from "@/components/aviator/BetsList";
import { MenuSheet } from "@/components/aviator/MenuSheet";
import { WalletDialog } from "@/components/aviator/WalletDialog";
import { getCurrentRound } from "@/server/game";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import {
  unlockAudio,
  playTakeoff,
  startFlying,
  updateFlying,
  stopFlying,
  startTension,
  updateTension,
  stopTension,
  playCrash,
} from "@/lib/sound";

export const Route = createFileRoute("/")({
  component: AviatorGame,
});

type Round = {
  id: number;
  phase: "waiting" | "flying" | "crashed";
  crash_at: number;
  flying_started_at: string | null;
  crashed_at: string | null;
  waiting_until: string;
};

function computeMultiplier(elapsedMs: number) {
  const t = elapsedMs / 1000;
  return Math.max(1, 1 + 0.05 * t + 0.05 * Math.pow(t, 1.7));
}

function AviatorGame() {
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const [round, setRound] = useState<Round | null>(null);
  const [recent, setRecent] = useState<{ id: number; crash_at: number }[]>([]);
  const [serverOffset, setServerOffset] = useState(0);
  const [multiplier, setMultiplier] = useState(1);
  const [countdown, setCountdown] = useState(0);
  const [crashedMult, setCrashedMult] = useState<number | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuPromoOpen, setMenuPromoOpen] = useState(false);
  const [walletOpen, setWalletOpen] = useState(false);
  const [walletTab, setWalletTab] = useState<"deposit" | "withdraw" | "history">("deposit");
  const [pendingBets, setPendingBets] = useState<Record<1 | 2, { id: number; amount: number; auto_cashout: number | null } | null>>({ 1: null, 2: null });
  const lastTickRef = useRef(0);
  const prevPhaseRef = useRef<Round["phase"] | null>(null);

  // Unlock audio on first user interaction
  useEffect(() => {
    const onAny = () => {
      unlockAudio();
      window.removeEventListener("pointerdown", onAny);
      window.removeEventListener("keydown", onAny);
    };
    window.addEventListener("pointerdown", onAny);
    window.addEventListener("keydown", onAny);
    return () => {
      window.removeEventListener("pointerdown", onAny);
      window.removeEventListener("keydown", onAny);
    };
  }, []);

  // Sound transitions on phase change
  useEffect(() => {
    const phase = round?.phase;
    if (!phase) return;
    const prev = prevPhaseRef.current;
    if (prev !== phase) {
      if (phase === "flying") {
        playTakeoff();
        startFlying();
        startTension();
      } else if (phase === "crashed") {
        stopFlying();
        stopTension();
        playCrash();
      } else if (phase === "waiting") {
        stopFlying();
        stopTension();
      }
      prevPhaseRef.current = phase;
    }
  }, [round?.phase]);

  // Update flying/tension intensity with multiplier
  useEffect(() => {
    if (round?.phase === "flying") {
      updateFlying(multiplier);
      updateTension(multiplier);
    }
  }, [multiplier, round?.phase]);

  // Poll server every 1s to advance round phases
  useEffect(() => {
    if (loading || !user) return;
    let cancelled = false;
    const tick = async () => {
      try {
        const res = await getCurrentRound();
        if (cancelled) return;
        setRound(res.round as Round);
        setRecent(res.recent.map((r) => ({ id: r.id, crash_at: Number(r.crash_at) })));
        setServerOffset(res.serverTime - Date.now());
      } catch {
        // ignore
      }
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [loading, user]);

  // Realtime round updates for snappier transitions
  useEffect(() => {
    const ch = supabase
      .channel("rounds")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "game_rounds" },
        (payload) => {
          if (payload.eventType === "INSERT" || payload.eventType === "UPDATE") {
            setRound((prev) => {
              const newR = payload.new as Round;
              if (!prev || newR.id >= prev.id) return newR;
              return prev;
            });
            if (payload.eventType === "UPDATE") {
              const newR = payload.new as Round;
              if (newR.phase === "crashed") setCrashedMult(Number(newR.crash_at));
            }
          }
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  // Local multiplier animation
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const now = Date.now() + serverOffset;
      if (round?.phase === "flying" && round.flying_started_at) {
        const startedAt = new Date(round.flying_started_at).getTime();
        const m = computeMultiplier(Math.max(0, now - startedAt));
        const capped = Math.min(m, Number(round.crash_at));
        if (now - lastTickRef.current > 30) {
          setMultiplier(capped);
          lastTickRef.current = now;
        }
      } else if (round?.phase === "waiting") {
        const end = new Date(round.waiting_until).getTime();
        setCountdown(Math.max(0, (end - now) / 1000));
        setMultiplier(1);
        setCrashedMult(null);
      } else if (round?.phase === "crashed") {
        setCrashedMult(Number(round.crash_at));
      }
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [round, serverOffset]);

  // Track user's bets in current round
  useEffect(() => {
    if (!user || !round) {
      setPendingBets({ 1: null, 2: null });
      return;
    }
    let cancelled = false;
    supabase
      .from("bets")
      .select("id, amount, panel, auto_cashout, status")
      .eq("user_id", user.id)
      .eq("round_id", round.id)
      .then(({ data }) => {
        if (cancelled || !data) return;
        const next: Record<1 | 2, { id: number; amount: number; auto_cashout: number | null } | null> = { 1: null, 2: null };
        for (const b of data) {
          if (b.status === "pending") {
            next[b.panel as 1 | 2] = { id: b.id, amount: Number(b.amount), auto_cashout: b.auto_cashout ? Number(b.auto_cashout) : null };
          }
        }
        setPendingBets(next);
      });

    const ch = supabase
      .channel("user-bets-" + user.id + "-" + round.id)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bets", filter: `user_id=eq.${user.id}` },
        (payload) => {
          const b = (payload.new ?? payload.old) as { id: number; amount: number; panel: number; auto_cashout: number | null; status: string; round_id: number };
          if (b.round_id !== round.id) return;
          setPendingBets((prev) => {
            const next = { ...prev };
            if (payload.eventType === "DELETE" || (payload.new && (payload.new as { status: string }).status !== "pending")) {
              next[b.panel as 1 | 2] = null;
            } else {
              next[b.panel as 1 | 2] = { id: b.id, amount: Number(b.amount), auto_cashout: b.auto_cashout ? Number(b.auto_cashout) : null };
            }
            return next;
          });
        },
      )
      .subscribe();
    return () => {
      cancelled = true;
      supabase.removeChannel(ch);
    };
  }, [user, round]);

  return (
    <div className="min-h-screen bg-[#0d0e10] text-foreground">
      <Header
        onMenuClick={() => {
          setMenuPromoOpen(false);
          setMenuOpen(true);
        }}
        onWalletClick={() => {
          setWalletTab("deposit");
          setWalletOpen(true);
        }}
        onWalletHistoryClick={() => {
          setWalletTab("history");
          setWalletOpen(true);
        }}
        onPromoClick={() => {
          setMenuPromoOpen(true);
          setMenuOpen(true);
        }}
      />
      <MultiplierStrip recent={recent} />
      <PlaneCanvas
        phase={round?.phase ?? "waiting"}
        multiplier={multiplier}
        countdownSec={countdown}
        crashedMultiplier={crashedMult}
      />
      <div className="px-3 py-3 space-y-3 max-w-[640px] mx-auto">
        <BetPanel
          panel={1}
          phase={round?.phase ?? "waiting"}
          roundId={round?.id ?? null}
          liveMultiplier={multiplier}
          pendingBet={pendingBets[1]}
        />
        <BetPanel
          panel={2}
          phase={round?.phase ?? "waiting"}
          roundId={round?.id ?? null}
          liveMultiplier={multiplier}
          pendingBet={pendingBets[2]}
        />
        <BetsList currentRoundId={round?.id ?? null} />
        {!profile && (
          <div className="text-center text-xs text-muted-foreground py-2">
            Connecting…
          </div>
        )}
      </div>
      <MenuSheet open={menuOpen} onOpenChange={setMenuOpen} initialPromoOpen={menuPromoOpen} />
      <WalletDialog open={walletOpen} onOpenChange={setWalletOpen} initialTab={walletTab} />
    </div>
  );
}
